def x ():
	print ('X')
