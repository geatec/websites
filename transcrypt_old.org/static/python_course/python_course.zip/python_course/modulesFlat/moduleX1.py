def x ():
	print ('x')
