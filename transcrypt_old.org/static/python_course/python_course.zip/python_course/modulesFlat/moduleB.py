def b ():
	print ('b')
