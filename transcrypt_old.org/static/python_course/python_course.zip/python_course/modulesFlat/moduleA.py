def a ():
	print ('a')
