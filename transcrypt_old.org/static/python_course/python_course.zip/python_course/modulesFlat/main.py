from moduleA import *
from moduleB import *
import moduleX1
import moduleX2

a ()
b ()
moduleX1.x ()
moduleX2.x ()
