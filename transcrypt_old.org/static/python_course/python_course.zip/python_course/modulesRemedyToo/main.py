from module import *

print (application.a)
f ()

application.a = 5
print

print (application.a)
f ()

print ('\nYou can\'t use \'from facadeModule import *\' in this case!')