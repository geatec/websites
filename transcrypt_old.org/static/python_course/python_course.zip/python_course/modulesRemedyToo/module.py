import application
# from application import *

application.a = 3

# print (a)

def f ():
	print (application.a)
