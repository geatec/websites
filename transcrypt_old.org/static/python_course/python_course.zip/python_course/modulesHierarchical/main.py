from group1.moduleA import *
from group2.moduleB import *
import group1.moduleX
import group2.moduleX

a ()
b ()
group1.moduleX.x ()
group2.moduleX.x ()
