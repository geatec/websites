from base import *

application.a = 3

def f ():
	print (application.a)