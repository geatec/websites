class Application:
	pass
	
application = Application
