from module import *

print (a)
f ()

a = 5
print

print (a)
f ()
