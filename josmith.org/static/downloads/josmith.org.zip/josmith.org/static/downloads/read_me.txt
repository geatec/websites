If alwaysdata.com is your provider, unpack the following files in your home directory:

modWsgi.zip
josmith.zip
josmith.org.zip

In the admin interface, choose Python 3.x as environment.
Adapt the site settings like shown in site_settings.png.
Restart processes.
That's it.
