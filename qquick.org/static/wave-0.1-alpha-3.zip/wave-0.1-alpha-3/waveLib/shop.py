# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from re import *

from eden import *
from waveLib.map import *
from waveLib.processor import *

class ItemWorkshop:
	def __init__ (self, dataManager):
	
		# --- Constants
	
		Creating, Filtering = range (2)
		
		AllAspects = range (Item.NrOfAspects)
		CreationAspects = AllAspects [0:3]
		
		# --- Export nodes
		
		self.aspectTreesNode = Node ()
		
		self.isCreatingNode = Node ()
		self.isFilteringNode = Node ()
		
		self.shopExpressionNode = Node ()
		self.doClearShopExpressionNode = Node (None)
		self.doUseAsShopExpressionNode = Node (None)
		self.isShopExpressionPresentNode = Node ()
		
		self.doApplyCreateNode = Node (None)
		
		self.doApplyFilterNode = Node (None)
		self.compiledInclusionListNode = Node ([])
		self.compiledExclusionListNode = Node ([])
		
		# --- Local nodes
		
		selectedActivityNode = Node (Creating)
		
		doExitShopNode = Node (None)
		
		doApplyAndExitFilterNode = Node (None)		
		doApplyAndExitCreateNode = Node (None)
			
		# --- Transit non-nodes
		
		self.dataManager = dataManager
		
		# --- Importers
		
		self.creationList = ShopList (self, CreationAspects, 'Creation', 'List of items to be created')
		
		self.inclusionList = ShopList (self, AllAspects, 'Inclusion', 'Leave out all items that don\'t match this list, unless it\'s empty')
		self.exclusionList = ShopList (self, AllAspects, 'Exclusion', 'Leave out all items that match this list')
		
		self.shopTrees = [ShopTree (self, aspect, Item.AspectNames [aspect]) for aspect in range (Item.NrOfAspects)]  # Depends upon lists
				
		# --- Dependencies

		self.aspectTreesNode.dependsOn ([application.dataMapNode], lambda: application.dataMapNode.new.getAspectTrees (range (Item.NrOfAspects)))

		self.doClearShopExpressionNode.dependsOn ([self.isCreatingNode, self.isFilteringNode], lambda: None)
		self.isShopExpressionPresentNode.dependsOn ([self.shopExpressionNode], lambda: len (self.shopExpressionNode.new) != 0)
		
		self.doApplyCreateNode.dependsOn ([doApplyAndExitCreateNode], lambda: None)
		self.isCreatingNode.dependsOn ([selectedActivityNode], lambda: selectedActivityNode.new == Creating)
				
		self.doApplyFilterNode.dependsOn ([doApplyAndExitFilterNode], lambda: None)
		self.isFilteringNode.dependsOn ([selectedActivityNode], lambda: selectedActivityNode.new == Filtering)

		self.compiledInclusionListNode.dependsOn (
			[self.inclusionList.listNode],
			lambda: [[compile (aspect) for aspect in item] for item in self.inclusionList.listNode.new]
		)

		self.compiledExclusionListNode.dependsOn (
			[self.exclusionList.listNode],
			lambda: [[compile (aspect) for aspect in item] for item in self.exclusionList.listNode.new]
		)				
					
		self.shopExpressionNode.dependsOn (
			[aspectTree.subExpressionNode for aspectTree in self.shopTrees],
			lambda: ''.join ([
				ifExpr (
					len (self.shopTrees [aspect] .subExpressionNode.new),
					Item.AspectNames [aspect] + ' = ' + self.shopTrees [aspect] .subExpressionNode.new + '   ',
					''
				) for aspect in range (Item.NrOfAspects)
			])
		)
		
		doExitShopNode.dependsOn ([doApplyAndExitFilterNode, doApplyAndExitCreateNode], lambda: None)

		# --- Views		

		applyCreateHint = 'Create all items of the Creation List'
		
		applyFilterHint = ( 
						'Reduce the number of displayed items by means of filtering:\n'
						'- Leave out all items that don\'t match the Inclusion List, unless it\'s empty\n'
						'- Also leave out all items that match the Exclusion List'
					)

		okHintTail = 'After that, close the Item Workshop'
		cancelHint = 'Close the Item Workshop without further action'

		createItemsPage = PageView (
			VGridView ([
				self.creationList.view,
				HGridView ([
					FillerView (), FillerView (), FillerView (),
					ButtonView (
						self.doApplyCreateNode,
						'Apply', 
						hint = applyCreateHint
					),
					ButtonView (
						doApplyAndExitCreateNode,
						'OK',
						hint = applyCreateHint + '\n' + okHintTail
						
					),
					ButtonView (
						doExitShopNode,
						'Cancel',
						hint = cancelHint
					)
				])
			]),
			'Create Items'
		)

		filterItemsPage = PageView (
			VGridView ([
				VSplitView (
					self.inclusionList.view,
					self.exclusionList.view
				),
				HGridView ([
					FillerView (), FillerView (), FillerView (),
					ButtonView (
						self.doApplyFilterNode,
						'Apply', 
						hint = applyFilterHint
					),
					ButtonView (
						doApplyAndExitFilterNode,
						'OK',
						hint = applyFilterHint + '\n' + okHintTail
						
					),
					ButtonView (
						doExitShopNode,
						'Cancel',
						hint = cancelHint
					)
				])
			]),
			'Filter Items'
		)
		
		self.view = ModelessView (
			VGridView ([
				HGridView ([
					ButtonView (
						self.doClearShopExpressionNode,
						'Clear Expression',
						hint = 'Clear Locator, Kind and Group part of expression'
					),
					TextView (
						self.shopExpressionNode,
						editable = False,
						hint = 'Expression to be added to the Creation, Inclusion or Exclusion List'
					),
					HExtensionView (), HExtensionView (), HExtensionView (), HExtensionView (), HExtensionView ()
				]),
				HSplitView (
					GroupView (
						TabbedView (
							pageViews =
								[
										PageView (self.shopTrees [aspect] .view, Item.AspectNames [aspect])
									for aspect in range (Item.NrOfExplicitAspects)
								]
								+
								[
										PageView (self.shopTrees [aspect] .view, Item.AspectNames [aspect], self.isFilteringNode)
									for aspect in range (Item.NrOfExplicitAspects, Item.NrOfAspects)
								]
						),
						'Expression Builder'
					),
					GroupView (
						TabbedView (
							pageViews = [createItemsPage, filterItemsPage],
							selectedIndex = selectedActivityNode
						),
						'Activity Selector'
					)
				)
			]),
			'Item Workshop'
		)
		
		# --- Actions
		
		doExitShopNode.action = self.view.exit
		
# --- Shop parts classes

class ShopTree:
	def __init__ (self, itemWorkshop, aspect, caption):
	
		# --- Aliases
		
		dataManager = itemWorkshop.dataManager
		
		# --- Export nodes
		
		self.subExpressionNode = Node ('')
		
		# --- Local nodes
		
		doClearSubExpressionNode = Node ()
		
		isSelectionNode = application.store.add (Node (False))
		isNegateNode = application.store.add (Node (False))
		isSubTreeNode = application.store.add (Node (True))
		isAnywhereNode = application.store.add (Node (False))	
		
		isEditableNode = Node ()
		isFilteringAndSelectionNode = Node ()
		isFilteringAndSelectionAndNotAnywhereNode = Node ()
		
		treeNode = Node ()
		selectedPathNode = Node ([])
		
		# --- Dependencies
	
		def getSubExpression ():
			if doClearSubExpressionNode.touched:
				return ''
				
			if itemWorkshop.creationList.doReloadNode.touched:
				if aspect < Item.NrOfExplicitAspects:
					return itemWorkshop.creationList.selectedListNode.old [0] [aspect]
				else:
					return ''
				
			if itemWorkshop.inclusionList.doReloadNode.touched:
				return itemWorkshop.inclusionList.selectedListNode.old [0] [aspect]
				
			if itemWorkshop.exclusionList.doReloadNode.touched:
				return itemWorkshop.exclusionList.selectedListNode.old [0] [aspect]
				
			if itemWorkshop.doUseAsShopExpressionNode.touched:
				if aspect < Item.ProcessorName:
					subExpression = dataManager.selectedItemListNode.old [0] .rsplit (':', 2) [aspect]
				else:
					producerRun = application.dataMapNode.old.items [dataManager.selectedItemListNode.old [0]] .outputSlot.run
					
					if aspect == Item.ProcessorName:
						subExpression = producerRun.processorName
					else:
						subExpression = producerRun.runKey
				
				if itemWorkshop.isFilteringNode.new:		
					return '^' + subExpression + '$'
				elif aspect in range (Item.NrOfExplicitAspects):
					return subExpression
				else:
					return ''
			
			if isSelectionNode.new:
				if selectedPathNode.new == []:
					return ''
				
				if itemWorkshop.isCreatingNode.new:
					return '/'.join (selectedPathNode.new)
				
				if isAnywhereNode.new:
					subExpression  = '(.*/)?' + selectedPathNode.new [len (selectedPathNode.new) - 1] + '(/.*)?'
				else:
					subExpression = '^' + '/'.join (selectedPathNode.new)
					
					if isSubTreeNode.new:
						subExpression += '(/.*)?'
					else:
						subExpression += '$'		

				if isNegateNode.new:
					subExpression = '(?!' + subExpression + ')'
							
				return subExpression
			else:					
				return self.subExpressionNode.old

		self.subExpressionNode.dependsOn (
			[
				doClearSubExpressionNode,
				itemWorkshop.creationList.doReloadNode,
				itemWorkshop.inclusionList.doReloadNode,
				itemWorkshop.exclusionList.doReloadNode,
				itemWorkshop.doUseAsShopExpressionNode,
				itemWorkshop.isFilteringNode,
				isSelectionNode,
				selectedPathNode,
				isNegateNode,
				isSubTreeNode,
				isAnywhereNode
			],
			getSubExpression
		)

		doClearSubExpressionNode.dependsOn ([itemWorkshop.doClearShopExpressionNode], lambda: None)
		
		treeNode.dependsOn ([itemWorkshop.aspectTreesNode], lambda: itemWorkshop.aspectTreesNode.new [aspect])		
		selectedPathNode.dependsOn ([doClearSubExpressionNode], lambda: [])		
		
		isSelectionNode.dependsOn (
			[
				itemWorkshop.creationList.doReloadNode,
				itemWorkshop.inclusionList.doReloadNode,
				itemWorkshop.exclusionList.doReloadNode,
				itemWorkshop.doUseAsShopExpressionNode
			],
			lambda: False
		)
		
		isEditableNode.dependsOn ([isSelectionNode], lambda: not isSelectionNode.new)
		
		isFilteringAndSelectionNode.dependsOn (
			[itemWorkshop.isFilteringNode, isSelectionNode],
			lambda: itemWorkshop.isFilteringNode.new and isSelectionNode.new
		)
		
		isFilteringAndSelectionAndNotAnywhereNode.dependsOn (
			[isFilteringAndSelectionNode, isAnywhereNode],
			lambda: isFilteringAndSelectionNode.new and not isAnywhereNode.new
		)		
				
		# --- Views

		self.view = VGridView ([
			HGridView ([
				ButtonView (doClearSubExpressionNode, 'Clear', hint = 'Clear ' + caption + ' part of expression'),
				TextView (
					valueNode = self.subExpressionNode,
					editable = isEditableNode,
					hint = caption + ' part of expression to be added to the Creation, Inclusion or Exclusion List'
				),
				HExtensionView (), HExtensionView ()
			]),
			GridView ([
				[
					CheckView (
						valueNode = isSelectionNode,
						caption = 'Selection',
						hint = 'Use selection from ' + caption + ' tree, rather than keyboard input of arbitrary expression'
					),
					CheckView (
						valueNode = isSubTreeNode,
						caption = 'Subtree',
						enabled = isFilteringAndSelectionAndNotAnywhereNode,
						hint = 'Select ' + caption + ' subtree, rather than ' + caption + ' tree node'
					)
				],
				[
					CheckView (
						valueNode = isNegateNode,
						caption = 'Negate',
						enabled = isFilteringAndSelectionNode,
						hint = 'Negate selected ' + caption
					),
					CheckView (
						valueNode = isAnywhereNode,
						caption = 'Anywhere',
						enabled = isFilteringAndSelectionNode,
						hint = 'Select same ' + caption + ' anywhere'
					)
				]
			]),
			TreeView (
				treeNode = treeNode,
				selectedPathNode = selectedPathNode,	
				enabled = isSelectionNode
			)
		])
		
class ShopList:
	def __init__ (self, itemWorkshop, aspects, caption, listHint):
	
		# --- Aliases
		
		dataManager = itemWorkshop.dataManager
		
		# --- Export nodes
		
		self.listNode = application.store.add (Node ([]))
		self.selectedListNode = Node ([])
		
		self.doReloadNode = Node (None)
		
		# --- Local nodes
		
		isSelectionMadeNode = Node ()
		isSingleSelectionMadeNode = Node ()
		
		doAddNode = Node (None)
		
		doDeleteNode = Node (None)
		doReloadAndDeleteNode = Node (None)
		
		# --- Dependencies
		
		isSelectionMadeNode.dependsOn ([self.selectedListNode], lambda: len (self.selectedListNode.new) > 0)
		isSingleSelectionMadeNode.dependsOn ([self.selectedListNode], lambda: len (self.selectedListNode.new) == 1)
		
		self.doReloadNode.dependsOn ([doReloadAndDeleteNode], lambda: None)		
		
		self.listNode.dependsOn (
			[doAddNode, doDeleteNode, doReloadAndDeleteNode],
			lambda: ifCall (
				doAddNode.touched,
				lambda: appendList (
					self.listNode.old,
					[[itemWorkshop.shopTrees [aspect] .subExpressionNode.old for aspect in aspects]]
				),
				lambda: shrinkList (self.listNode.old, self.selectedListNode.old)
			)
		)

		# --- Views
		
		self.view =	HGridView ([
			VGridView ([
				FillerView (), FillerView (),
				ButtonView (
					actionNode = doAddNode,
					icon = 'rightArrowPlus',
					hint = lambda: 'Add expression to ' + caption +' List:\n' + itemWorkshop.shopExpressionNode.new,
					enabled = itemWorkshop.isShopExpressionPresentNode
				),
				ButtonView (
					actionNode = doReloadAndDeleteNode,
					icon = 'leftArrowMinus',
					hint = lambda: 'Move selected expression from ' + caption + ' List to Expression Builder',
					enabled = isSingleSelectionMadeNode
				),
				ButtonView (
					actionNode = self.doReloadNode,
					icon = 'leftArrow',
					hint = lambda: 'Copy selected expression from ' + caption + ' List to Expression Builder',
					enabled = isSingleSelectionMadeNode
				),
				ButtonView (
					actionNode = doDeleteNode,
					icon = 'leftCrossMinus',
					hint = lambda: 'Delete selected expression from ' + caption + ' List',
					enabled = isSingleSelectionMadeNode
				)
			]),
			VGridView ([
				LLabelView (
					caption = caption + ' List',
					hint = listHint
				),
				ListView (
					listNode = self.listNode,
					columnLabels = [Item.AspectNames [aspect] for aspect in aspects],
					selectedListNode = self.selectedListNode,	
					contextMenuView = ContextMenuView ([
						MenuButtonView (
							actionNode = doDeleteNode,
							caption = 'Delete',
							enabled = isSelectionMadeNode
						)
					])
				)
			]),
			HExtensionView (), HExtensionView (), HExtensionView (), HExtensionView ()
		])
