/*
# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.
*/

#include <process.h>
#include <fstream>
#include <iostream>

using namespace std;

void main (int argCount, char *argVec []) {
	char *runKey = argVec [1];
	char *progName = argVec [2];

	char **progArgs = new char* [argCount - 1];	// Leave out argVect entries 0, 1 and 2, prepend progName, append sentry

	progArgs [0] = progName;
	for (int index = 3; index < argCount; index++) {
		progArgs [index - 2] = argVec [index];
	}
	progArgs [argCount - 2] = 0;

	_spawnv (_P_WAIT, progName, progArgs); 

	ofstream ofs (runKey);
}
