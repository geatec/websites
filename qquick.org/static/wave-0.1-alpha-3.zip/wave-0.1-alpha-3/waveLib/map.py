# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from eden import *
from waveLib.platform import *
from waveLib.xml import *

class Run:
	Empty = -1
	Invalid = 0
	Dry = 1
	Trial = 2
	Full = 3

	def __init__ (self, runKey = None, processorName = None, updateLevel = Empty, owningWaveNr = 0):
		self.runKey = runKey
		self.processorName = processorName
		self.inputSlots = []
		self.outputSlots = []
		self.updateLevel = updateLevel
		self.owningWaveNr = owningWaveNr
		
	def invalidate (self, owningWaveNr):
		if self.updateLevel != Run.Invalid:
			self.updateLevel = Run.Invalid
			self.owningWaveNr = owningWaveNr
			
			for outputSlot in self.outputSlots:
				for item in outputSlot.items:
					for inputSlot in item.inputSlots:
						inputSlot.run.invalidate (owningWaveNr)
						
	def inputsUpdated (self, updateLevel):
		for inputSlot in self.inputSlots:
			for item in inputSlot.items:
				if item.outputSlot.run.updateLevel < updateLevel:
					return False
		return True

class Slot:
	def __init__ (self, slotName = None, run = None):
		self.slotName = slotName
		self.run = run									# This run is the exclusive owner of the slot
		self.items = []									# But if there are no items left in a slot, the owning run discards it
		
class Item:
	NrOfAspects = 5
	NrOfExplicitAspects = 3
	Locator, Kind, Group, ProcessorName, RunKey = range (NrOfAspects)
	AspectNames = ['Locator', 'Kind', 'Group', 'Processor', 'Run']

	def __init__ (self, itemKey = None):
		self.itemKey = itemKey
		self.outputSlot = None	# The one and only slot that produced the Item
		self.inputSlots = []

class DataMap:
	def __init__ (self):
		self.currentWaveNr = UniqueNumber (int (1E9))
		self.currentRunNr = UniqueNumber (int (1E9))
		
		self.items = {}
		self.runs = {}
		
	def newWave (self):
		self.currentRunNr.reset ()
		return self.currentWaveNr.getNext ()
		
	def disownAll (self):
		for runKey in self.runs:
			self.owingWaveNr = 0
	
	def getParamStoreName (self, runKey):
		return application.ProjectDirectory + '/' + runKey.replace ('/', '~') + '.store'
	
	def registerRun (self, processorName, inputKeySlots, outputKeySlots, paramStore, updateLevel, owningWaveNr = 0):
		runKey = str (self.currentWaveNr ()) [1:] + '/' + str (self.currentRunNr.getNext ()) [1:]
		run = Run (runKey = runKey, processorName = processorName)
		self.runs [runKey] = run
		
		for inputKeySlot in inputKeySlots:
			inputSlot = Slot (inputKeySlot [0], run)
			for itemKey in inputKeySlot [1]:
				item = self.items [itemKey]
				inputSlot.items.append (item)
				item.inputSlots.append (inputSlot)
			run.inputSlots.append (inputSlot)
			
		for outputKeySlot in outputKeySlots:
			outputSlot = Slot (outputKeySlot [0], run)
			for itemKey in outputKeySlot [1]:
				try:
					item = self.items [itemKey]
					self.detachParents (item, paramStore)
				except:	
					item = Item (itemKey)
					self.items [itemKey] = item
					
				outputSlot.items.append (item)
				item.outputSlot = outputSlot
			run.outputSlots.append (outputSlot)
			
		run.invalidate (owningWaveNr)
		run.updateLevel = updateLevel
		
		if paramStore:
			paramStore.save (self.getParamStoreName (runKey))
			
		return runKey

	def loadParamStore (self, paramStore, runKey):
		paramStore.load (self.getParamStoreName (runKey))
		
	def getPendingRunKeys (self, updateLevel):
		return [runKey for runKey in self.runs if self.runs [runKey] .updateLevel < updateLevel]
		
	def detachParents (self, item, deleteData):
		item.outputSlot.items.remove (item)								# Remove item from its outputSlot
		
		if not len (item.outputSlot.items):								# If that outputSlot has no items left
			item.outputSlot.run.outputSlots.remove (item.outputSlot)	#	Remove also the outputSlot from its run
			
		if not len (item.outputSlot.run.outputSlots):					# If the run that produced the item has no outputSlots left
			del self.runs [item.outputSlot.run.runKey]					#	Remove that run from the dataMap
			
			if deleteData:
				deleteFile (self.getParamStoreName (item.outputSlot.run.runKey))

			for inputSlot in item.outputSlot.run.inputSlots:			# For each inputSlot of the removed run
				for item in inputSlot.items:							#	For each item in that inputSlot
					item.inputSlots.remove (inputSlot)					#	Remove the inputSlot from the item
					
	def detachChildren (self, item):
		for inputSlot in item.inputSlots:								# For each inputSlot that contains the removed item
			inputSlot.items.remove (item)								#	Remove the item from that inputSlot
			
			if not len (inputSlot.items):								#	If that inputSlot has no items left
				inputSlot.run.inputSlots.remove (inputSlot		)		#		Remove also the inputSlot from its run
	
	def removeItem (self, itemKey):
		item = self.items [itemKey]
		del self.items [itemKey]		
		self.detachParents (item, True)
		self.detachChildren (item)
																
	items = {} 
	runs = {}
	
	def clone (self):
		mapClone = DataMap ()
		mapClone.fileName = self.fileName
		
		mapClone.currentRunNr.value = self.currentRunNr ()
		mapClone.currentWaveNr.value = self.currentWaveNr ()

		for itemKey in self.items:
			mapClone.items [itemKey] = Item (itemKey)			
			
		for runKey in self.runs:
			run = self.runs [runKey]
			runClone = Run (runKey, run.processorName, run.updateLevel, run.owningWaveNr)
			mapClone.runs [runKey] = runClone

			for inputSlot in run.inputSlots:
				inputSlotClone = Slot (inputSlot.slotName, runClone)
				runClone.inputSlots.append (inputSlotClone)
				for inputItem in inputSlot.items:
					inputItemClone = mapClone.items [inputItem.itemKey]
					inputSlotClone.items.append (inputItemClone)
					inputItemClone.inputSlots.append (inputSlotClone)
							
			for outputSlot in run.outputSlots:
				outputSlotClone = Slot (outputSlot.slotName, runClone)
				runClone.outputSlots.append (outputSlotClone)
				for outputItem in outputSlot.items:
					outputItemClone = mapClone.items [outputItem.itemKey]
					outputSlotClone.items.append (outputItemClone)
					outputItemClone.outputSlot = outputSlotClone
					
		return mapClone
	
	def name (self, fileName):
		self.fileName = fileName
	
	def load (self, fileName = None):
		if fileName:
			self.fileName = fileName
			
		mapReader = XmlReader ()
		mapReader.open (self.fileName)
	
		if mapReader.readOpenTag ('dataMap', True):
			fixupItemKey = None
		
			self.currentWaveNr.value = int (mapReader.readClause ('currentWaveNr'))
			self.currentRunNr.value = int (mapReader.readClause ('currentRunNr'))
			
			if mapReader.readOpenTag ('items'):
				while mapReader.readOpenTag ('item', True):
					item = Item ()
					item.itemKey = mapReader.readClause ('itemKey')
					self.items [item.itemKey] = item
					mapReader.readCloseTag ()
				mapReader.readCloseTag ()
					
			if mapReader.readOpenTag ('runs'):
				while mapReader.readOpenTag ('run', True):
					run = Run ()
					run.runKey = mapReader.readClause ('runKey')
					run.processorName = mapReader.readClause ('processorName')
					run.updateLevel = int (mapReader.readClause ('updateLevel'))
					run.owningWaveNr = int (mapReader.readClause ('owningWaveNr'))
					
					if mapReader.readOpenTag ('inputSlots'):	
						while mapReader.readOpenTag ('inputSlot', True):
							inputSlot = Slot (run = run)
							inputSlot.slotName = mapReader.readClause ('inputSlotName')
							if mapReader.readOpenTag ('inputItems'):
								while True:
									fixupItemKey = mapReader.readClause ('inputItemKey', True)
									
									if not fixupItemKey:
										break
										
									inputItem = self.items [fixupItemKey]
									inputItem.inputSlots.append (inputSlot)
									inputSlot.items.append (inputItem)
								mapReader.readCloseTag ()	
							run.inputSlots.append (inputSlot)
							mapReader.readCloseTag ()
						mapReader.readCloseTag ()
					
					if mapReader.readOpenTag ('outputSlots'):	
						while mapReader.readOpenTag ('outputSlot', True):
							outputSlot = Slot (run = run)
							outputSlot.slotName = mapReader.readClause ('outputSlotName')
							if mapReader.readOpenTag ('outputItems'):
								while True:
									fixupItemKey = mapReader.readClause ('outputItemKey', True)
									
									if not fixupItemKey:
										break
										
									outputItem = self.items [fixupItemKey]
									outputItem.outputSlot = outputSlot
									outputSlot.items.append (outputItem)
								mapReader.readCloseTag ()	
							run.outputSlots.append (outputSlot)
							mapReader.readCloseTag ()
						mapReader.readCloseTag ()
					
					self.runs [run.runKey] = run
					mapReader.readCloseTag ('run')
				mapReader.readCloseTag ('runs')
					
			mapReader.readCloseTag ('dataMap')
			
		mapReader.close ()
			
	def save (self, fileName = None):
		if fileName:
			self.fileName = fileName
			
		mapWriter = XmlWriter ()
		mapWriter.open (self.fileName)
	
		if mapWriter.writeOpenTag ('dataMap'):
			mapWriter.writeClause ('currentWaveNr', self.currentWaveNr ())
			mapWriter.writeClause ('currentRunNr', self.currentRunNr ())

			if mapWriter.writeOpenTag ('items'):
				for itemKey in sorted (self.items):
					item = self.items [itemKey]
					mapWriter.writeOpenTag ('item')
					mapWriter.writeClause ('itemKey', item.itemKey)
					mapWriter.writeCloseTag ()
				mapWriter.writeCloseTag ()
			
			if mapWriter.writeOpenTag ('runs'):
				for runKey in sorted (self.runs):
					run = self.runs [runKey]
					mapWriter.writeOpenTag ('run')
					mapWriter.writeClause ('runKey', run.runKey)				
					mapWriter.writeClause ('processorName', run.processorName)
					mapWriter.writeClause ('updateLevel', run.updateLevel)
					mapWriter.writeClause ('owningWaveNr', run.owningWaveNr)
					
					if mapWriter.writeOpenTag ('inputSlots'):	
						for inputSlot in run.inputSlots:
							mapWriter.writeOpenTag ('inputSlot')
							mapWriter.writeClause ('inputSlotName', inputSlot.slotName)
							if mapWriter.writeOpenTag ('inputItems'):
								for inputItem in inputSlot.items:
									mapWriter.writeClause ('inputItemKey', inputItem.itemKey)
								mapWriter.writeCloseTag ()
							mapWriter.writeCloseTag ()
						mapWriter.writeCloseTag ()
							
					if mapWriter.writeOpenTag ('outputSlots'):
						for outputSlot in run.outputSlots:
							mapWriter.writeOpenTag ('outputSlot')
							mapWriter.writeClause ('outputSlotName', outputSlot.slotName)
							if mapWriter.writeOpenTag ('outputItems'):
								for outputItem in outputSlot.items:
									mapWriter.writeClause ('outputItemKey', outputItem.itemKey)
								mapWriter.writeCloseTag ()
							mapWriter.writeCloseTag ()
						mapWriter.writeCloseTag ()
						
					mapWriter.writeCloseTag ('run')
				mapWriter.writeCloseTag ('runs')	
			mapWriter.writeCloseTag ('dataMap')
					
		mapWriter.close ()

	def getAspectTrees (self, aspects):
		aspectTrees = []
		producerRunNeeded = False
		
		for aspect in range (Item.NrOfAspects):
			if aspect in aspects:
				aspectTrees.append  ([])
				if aspect > Item.ProcessorName:
					producerRunNeeded = True
			else:
				aspectTrees.append (None)

		for itemKey in self.items:
			if producerRunNeeded:
				producerRun = self.items [itemKey].outputSlot.run

			for aspect in aspects:
				if aspect < Item.ProcessorName:
					aspectPath = itemKey.rsplit (':', 2) [aspect]
				elif aspect == Item.ProcessorName:
					aspectPath = producerRun.processorName
				else:
					aspectPath = producerRun.runKey
					
				insertPath (aspectTrees [aspect], aspectPath.rsplit ('/'))
				
		for aspect in range (Item.NrOfAspects):
			if aspect in aspects:
				sortTree (aspectTrees [aspect])
				
		return aspectTrees
