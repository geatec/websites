# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

class ScriptWriter:
	def __init__ (self, fileName = None):
		self.initialize (fileName)

	def initialize (self, fileName = None):
		if fileName:
			self.fileName = fileName
			
		self.lines = []
		
		self.lines.append ('from executor import *')
		self.lines.append ('')
		
		self.lines.append ('def script ():')
		self.lines.append ('')
		
	def emitLine (self, line):
		self.lines.append ('\t' + line)
	
	def terminate (self, fileName = None):
		if fileName:
			self.fileName = fileName
			
		self.lines.append ('')
		self.lines.append ('execute (script)')
			
		file = open (fileName, 'w')
		file.write ('\n'.join (self.lines))
		file.close ()
