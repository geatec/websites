# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from eden import *

codedSpace = '~'

class XmlReader:
	def open (self, fileName):
		self.tagNameStack = []
		
		file = open (fileName, 'r')
		self.words = file.read () .split ()
		file.close ()
			
		self.wordIndex = 0

	def close (self):
		pass

	def readOpenTag (self, tagName, optional = False):
		ok =  self.words [self.wordIndex] == '<' + tagName + '>'

		if ok:
			self.tagNameStack.append (tagName)
			self.wordIndex += 1
		elif not optional:
			raise Error ('Datamap corrupt, expected = <' + tagName + '>, found = ' + self.words [self.wordIndex])
			
		return ok
	
	def readCloseTag (self, tagName = None):
		openTagName = self.tagNameStack.pop ()
		
		if tagName and tagName != openTagName:
			raise Error ('Datamap reader internal inconsistency, openTagName = ' + openTagName + ', closeTagName = ' + tagName)
		
		ok = self.words [self.wordIndex] == '</' + openTagName + '>'
		
		if ok:
			self.wordIndex += 1
		else:
			raise Error ('Datamap corrupt, expected = </' + openTagName + '>, found = ' + self.words [self.wordIndex])
			
		return ok
			
	def readClause (self, tagName, optional = False):
		if not self.readOpenTag (tagName, optional):
			return False
			
		targetField = self.readTargetField ()
		self.readCloseTag ()
		return targetField

	def readTargetField (self):
		targetField = self.decode (self.words [self.wordIndex])
		self.wordIndex += 1
		return targetField
		
	def decode (self, string):
		return string.replace (codedSpace, ' ')
	
class XmlWriter:
	def open (self, fileName):
		self.tagNameStack = []
		self.fileName = fileName
		self.lines = []
		self.nrOfTabs = 0

	def close (self):
		file = open (self.fileName, 'w')
		file.write ('\n'.join (self.lines))
		file.close ()

	def writeOpenTag (self, tagName):
		self.tagNameStack.append (tagName)
		self.lines.append (self.getTabs () + '<' + tagName + '>')
		self.nrOfTabs += 1
		return True
	
	def writeCloseTag (self, tagName = None):
		self.nrOfTabs -= 1
		openTagName = self.tagNameStack.pop ()
		
		if tagName and tagName != openTagName:
			raise Error ('Datamap writer internal inconsistency, openTagName = ' + openTagName + ', closeTagName = ' + tagName)
			
		self.lines.append (self.getTabs () + '</' + openTagName + '>')
		
	def writeClause (self, tagName, sourceField):
		self.lines.append (self.getTabs () + '<' + tagName + '> ' + self.encode (str (sourceField)) + ' </' + tagName + '>')
		
	def encode (self, string):
		return string.replace (' ', codedSpace)
		
	def getTabs (self):
		return ''.join (['\t' for tabIndex in range (self.nrOfTabs)])
		