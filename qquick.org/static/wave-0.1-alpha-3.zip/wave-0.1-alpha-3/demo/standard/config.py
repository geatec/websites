# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from waveLib.base import * # !!! Change to import wave and solve consequences e.g. by including config in base and base everywhere else.

application.DemoDirectory = application.WaveDirectory + '/demo'
application.ApplicationDirectory = application.DemoDirectory + '/standard'
application.RepertoireDirectory = application.DemoDirectory + '/repertoire'
application.ProjectDirectory = application.ApplicationDirectory + '/project'
application.DataDirectory = application.ApplicationDirectory + '/data'				# Needed until DataBroker is ready
# application.ScriptDirectory = application.ApplicationDirectory + '/script'		# Unneeded, scripts can be anywhere
application.BitMapDirectories = [application.EdenLibDirectory, application.WaveLibDirectory]

import sys
sys.path.append (application.RepertoireDirectory)
