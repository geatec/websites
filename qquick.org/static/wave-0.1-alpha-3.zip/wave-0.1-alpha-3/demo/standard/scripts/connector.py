import sys

sys.path.extend ([
	'C:/activ_dell/prog/qQuick/wave-0.1-alpha-2/demo/standard',
	'C:/activ_dell/prog/qQuick/wave-0.1-alpha-2/demo/repertoire'
])

from executor import *
