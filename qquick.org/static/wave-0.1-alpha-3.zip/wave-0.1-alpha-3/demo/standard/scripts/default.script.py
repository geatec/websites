from connector import *

def script ():
	pass

	producers__rampgenerator (
		nrOfSamples = 100,
		startIndex = 20,
		startValue = -10.0,
		stopIndex = 80,
		stopValue = 8.0,
		outputSignal = ['a:vector:']
	)
	

executeScript (script)