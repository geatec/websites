from connector import *

def script ():
	pass

	producers__rampgenerator (
		nrOfSamples = 100,
		startIndex = 20,
		startValue = -10.0,
		stopIndex = 80,
		stopValue = 8.0,
		outputSignal = ['a:vector:']
	)
	
	producers__rampgenerator (
		nrOfSamples = 100,
		startIndex = 20,
		startValue = 0.0,
		stopIndex = 80,
		stopValue = 8.0,
		outputSignal = ['b:vector:']
	)
	
	transformers__adder (
		inputSignal1 = ['b:vector:'],
		inputSignal2 = ['a:vector:'],
		outputSignal = ['b:vector:']
	)
	
	producers__rampgenerator (
		nrOfSamples = 100,
		startIndex = 20,
		startValue = 0.0,
		stopIndex = 80,
		stopValue = 30.0,
		outputSignal = ['b:vector:']
	)
	
	transformers__adder (
		inputSignal1 = ['a:vector:'],
		inputSignal2 = ['b:vector:'],
		outputSignal = ['c:vector:']
	)
	
	transformers__amplifier (
		amplification = 1.0,
		inputSignal = ['c:vector:'],
		outputSignal = ['d:vector:']
	)
	
	consumers__plotter (
		plotList = ['a:vector:', 'b:vector:', 'c:vector:', 'd:vector:'],
		plotName = ['e:plot:']
	)
	
	transformers__amplifier (
		amplification = -1.0,
		inputSignal = ['c:vector:'],
		outputSignal = ['d:vector:']
	)
	
	consumers__plotter (
		plotList = ['a:vector:', 'b:vector:', 'c:vector:', 'd:vector:'],
		plotName = ['e:plot:']
	)
	

executeScript (script)