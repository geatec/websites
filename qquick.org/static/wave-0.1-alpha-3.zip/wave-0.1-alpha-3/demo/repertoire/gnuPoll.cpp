/*
# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.
*/

#include <windows.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>

#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <string>
#include <algorithm>

using namespace std;

void main (int argCount, char *argVec []) {
	string fileName = argVec [1];

	string forwardSlashFileName = fileName;
	replace (forwardSlashFileName.begin (), forwardSlashFileName.end (), '\\', '/');

	long readTime = 0;
	for (;;) {
		struct __stat64 fileStatus;
		_stat64 (fileName.c_str (), &fileStatus);
		long writeTime = fileStatus.st_mtime;
		if (writeTime > readTime) {
			cout << "load \"" << forwardSlashFileName << "\"" << endl;
			readTime = writeTime;
		}
		Sleep (1000);
	}
}
