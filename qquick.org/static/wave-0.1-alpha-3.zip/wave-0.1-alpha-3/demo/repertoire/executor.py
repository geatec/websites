from repertoire import *

application.repertoire = Repertoire ()
application.repertoire.addProcessors ()

producers__rampgenerator__instance = instantiateProcessor ('producers/rampgenerator')

def producers__rampgenerator (
	nrOfSamples,
	startIndex,
	startValue,
	stopIndex,
	stopValue,
	outputSignal
):
	producers__rampgenerator__instance.nrOfSamplesNode.change (nrOfSamples)
	producers__rampgenerator__instance.startIndexNode.change (startIndex)
	producers__rampgenerator__instance.startValueNode.change (startValue)
	producers__rampgenerator__instance.stopIndexNode.change (stopIndex)
	producers__rampgenerator__instance.stopValueNode.change (stopValue)
	producers__rampgenerator__instance.outputSignalNode.change (outputSignal)
	producers__rampgenerator__instance.scriptedRun ()

consumers__plotter__instance = instantiateProcessor ('consumers/plotter')

def consumers__plotter (
	plotList,
	plotName
):
	consumers__plotter__instance.plotListNode.change (plotList)
	consumers__plotter__instance.plotNameNode.change (plotName)
	consumers__plotter__instance.scriptedRun ()

transformers__amplifier__instance = instantiateProcessor ('transformers/amplifier')

def transformers__amplifier (
	amplification,
	inputSignal,
	outputSignal
):
	transformers__amplifier__instance.amplificationNode.change (amplification)
	transformers__amplifier__instance.inputSignalNode.change (inputSignal)
	transformers__amplifier__instance.outputSignalNode.change (outputSignal)
	transformers__amplifier__instance.scriptedRun ()

transformers__adder__instance = instantiateProcessor ('transformers/adder')

def transformers__adder (
	inputSignal1,
	inputSignal2,
	outputSignal
):
	transformers__adder__instance.inputSignal1Node.change (inputSignal1)
	transformers__adder__instance.inputSignal2Node.change (inputSignal2)
	transformers__adder__instance.outputSignalNode.change (outputSignal)
	transformers__adder__instance.scriptedRun ()
