# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from waveLib.processor import *

def fileNames (itemList):
	return ' '.join ([application.DataDirectory + '/' + itemKey.replace ('/', '!') .replace (':', '__') for itemKey in itemList])

class Adder (BatchProcessor):
	def __init__ (self, processorName):
		Processor.__init__ (self, processorName)
		
		self.defInput ('inputSignal1', ['none'])
		self.defInput ('inputSignal2', ['none'])
		self.defOutput ('outputSignal', ['none'])
		
	def getArguments (self):
		return (
			fileNames (self.inputSignal1Node.new) + ' ' +
			fileNames (self.inputSignal2Node.new) + ' ' +
			fileNames (self.outputSignalNode.new)
		)
		
	def getExecutable (self):
		return application.RepertoireDirectory + '/adder.exe'
		
	def createView (self):
		return 	GridView ([
			[
				LLabelView ('Input signal 1'),
				ItemView (self.inputSignal1Node)
			],
			[
				LLabelView ('Input signal 2'),
				ItemView (self.inputSignal2Node)
			],
			[
				LLabelView ('Output signal'),
				ItemView (self.outputSignalNode)
			]
		])

class Amplifier (BatchProcessor):
	def __init__ (self, processorName):
		Processor.__init__ (self, processorName)
	
		self.defParam ('amplification', 1.0)
		self.defInput ('inputSignal', ['none'])
		self.defOutput ('outputSignal', ['none'])
		
	def getArguments (self):
		return (
			str (self.amplificationNode.new) + ' ' +
			fileNames (self.inputSignalNode.new) + ' ' +
			fileNames (self.outputSignalNode.new)
		)
		
	def getExecutable (self):
		return application.RepertoireDirectory + '/amplifier.exe'

	def createView (self):
		return 	GridView ([
			[
				LLabelView ('Input signal'),
				ItemView (self.inputSignalNode)
			],
			[
				LLabelView ('Output signal'),
				ItemView (self.outputSignalNode)
			],
			[
				LLabelView ('Amplification'),
				TextView (self.amplificationNode)
			]
		])

class Plotter (BatchProcessor):
	def __init__ (self, processorName):
		Processor.__init__ (self, processorName)
	
		self.defInput ('plotList', [])
		self.defOutput ('plotName', ['none'])
		
	def getArguments (self):
		return fileNames (self.plotNameNode.new + self.plotListNode.new)
		
	def getExecutable (self):
		return application.RepertoireDirectory + '/plotter.exe'

	def createView (self):
		return 	GridView ([
			[
				LLabelView ('Plot list'),
				ItemListView (self.plotListNode)
			],
			[
				LLabelView ('Plot name'),
				ItemView (self.plotNameNode)
			],
		])

class RampGenerator (BatchProcessor):
	def __init__ (self, processorName):
		Processor.__init__ (self, processorName)
		
		self.defParam ('nrOfSamples', 100)
		self.defParam ('startIndex', 20)
		self.defParam ('startValue', -10.0)
		self.defParam ('stopIndex', 80)
		self.defParam ('stopValue', 8.0)
		self.defOutput ('outputSignal', ['none'])
			
	def getArguments (self):
		return (
			str (self.nrOfSamplesNode.new) + ' ' +
			str (self.startIndexNode.new) + ' ' +
			str (self.startValueNode.new) + ' ' +
			str (self.stopIndexNode.new) + ' ' +
			str (self.stopValueNode.new) + ' ' +
			fileNames (self.outputSignalNode.new)
		)
			
	def getExecutable (self):
		return application.RepertoireDirectory + '/rampGenerator.exe'
		
	def createView (self):
		return GridView ([
			[
				LLabelView ('Output signal'),
				ItemView (self.outputSignalNode)
			],
			[
				LLabelView ('Nr. of samples'),
				TextView (self.nrOfSamplesNode)
			],
			[
				LLabelView ('Start index'),
				TextView (self.startIndexNode)
			],
			[
				LLabelView ('Amplitude at start index'),
				TextView (self.startValueNode)
			],
			[
				LLabelView ('Stop index'),
				TextView (self.stopIndexNode)
			],
			[
				LLabelView ('Amplitude at stop index'),
				TextView (self.stopValueNode)
			]
		])

class Repertoire (BaseRepertoire):
	def __init__ (self):
		BaseRepertoire.__init__ (self)

	def addProcessors (self):
		self.addProcessorClass ('producers/rampgenerator', RampGenerator)
		self.addProcessorClass ('consumers/plotter', Plotter)
		self.addProcessorClass ('transformers/amplifier', Amplifier)
		self.addProcessorClass ('transformers/adder', Adder)

