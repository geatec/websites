/*
# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.
*/

#include <fstream>
#include <stdlib.h>
#include <string>

using namespace std;

void main (int argCount, char *argVec []) {
	ofstream plotFile (argVec [1]);

	plotFile << "plot [0:100] [-20:20] 0" << endl;

	for (int argIndex = 2; argIndex < argCount; argIndex++) {
		plotFile << "replot \"" << argVec [argIndex] << "\" with lines" << endl;
	}
	
	plotFile.close ();
}
