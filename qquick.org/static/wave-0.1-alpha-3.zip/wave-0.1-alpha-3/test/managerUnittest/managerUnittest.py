# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from wave.map import *

def crowdDataMap (dataMap):
	def id (index):
		return str (1001 + index) [1:4]
		
	processors = ['adder', 'subtractor', 'multiplier', 'divider', 'averager']	#, 'bandfilter', 'clipper']
	kinds = ['impedance', 'reflectivity', 'weight', 'saturation']
	
	for year in ['2000', '2001']:	#, '2003', '2004', '2005']:
		for person in ['john', 'mary']:
			for attempt in ['guess', 'optimized']:
				group = year + '/' + person + '/' + attempt
				for stage in ['pre', 'main', 'post']:
					dataMap.newWave ()
					for containerKind in ['volume', 'well']:
						containerLocator = stage
						dataMap.registerRun ('factory', [], [('containers', [containerLocator + ':' + containerKind + ':' + group])], None, Run.Full)
			
#						for processorIndex in range (7): 
						for processorIndex in range (5): 
							inputSlots = []
							if processorIndex:
								for inputSlotIndex in range (4):
									inputSlot = ('inputSlot' + id (inputSlotIndex), [])
									for inputItemIndex in range (2):
										inputSlot [1] .append (
											containerLocator + '/' + processors [processorIndex - 1] + '_S' + id (inputSlotIndex) + '_I' + id (inputItemIndex) + ':' +
											containerKind + '/' + kinds [inputSlotIndex] + ':' +
											group
										)
									inputSlots.append (inputSlot)
									
							outputSlots = []
							for outputSlotIndex in range (4):
								outputSlot = ('outputSlot' + id (outputSlotIndex), [])
								for outputItemIndex in range (2):
									outputSlot [1] .append (
										containerLocator + '/' + processors [processorIndex] + '_S' + id (outputSlotIndex) + '_I' + id (outputItemIndex) + ':' +
										containerKind + '/' + kinds [outputSlotIndex] + ':' +
										group
									)
								outputSlots.append (outputSlot)
								
							dataMap.registerRun (processors [processorIndex], inputSlots, outputSlots, None, Run.Full)
