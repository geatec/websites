# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from wave.xml import *

writer = XmlWriter ()

writer.open ('test.xml')

writer.writeOpenTag ('test')
writer.writeClause ('number', 100)
writer.writeCloseTag ()

writer.close ()

print 'Writing done'

reader = XmlReader ()

reader.open ('test.xml')

reader.readOpenTag ('test')
number = int (reader.readClause ('number'))
reader.readCloseTag ()

reader.close ()

print number

print 'Reading done'



