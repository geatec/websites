# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.


Purpose
=======

QQuick currently consists of two parts:

1. Eden (Event Driven Evaluation Nodes)

Eden is a library that allows rapid construction of applications with the following internal characteristics:

- Interdependencies between variables are captured by the Event Driven Evaluation Node pattern. This is a highly improved version of the wellknown Observer pattern, allowing cyclic dependencies, rollback and caching.
- GUI's are constructed by nesting Views (see demo and tutorials). Layout management is automatic. All dialogs are scalable.
- Full drag and drop support, including drag and drop reordering is enabled for lists and trees. 
- Both data and layout are persistent.


2. Wave (Wave Activated Versioning Engine)

Wave is an application framework for turning a set of bare bones command line computational programs into a datacentric, scriptable GUI-application with full datalineage management and automatic recomputation at parameter changes.

Wave is also a quite elaborated example of how to use and benefit from the Eden library.


System requirements
===================

Windows XP
DotNet 2.0 + SDK
IronPython 1.0 Beta 7
Python 2.4 (CPython, that is)


Status
======

Eden is rather stable, although the set of Views is bound to grow. If you build an app with it, it's unlikely you'll have to change much for the final version.

Wave is still incomplete and in flux. The demo is worth trying though. It illustrates the underlying concepts that are unlikely to change a lot. The unittests lag back, hence are currently to be considered broken.

Documentation is sorely missing. It will be added A.S.A.P. Priority will be given to document Eden.


Recent changes
==============

Most important changes from eden-0.1-alpha-2 to eden-0.1-alpha-3:

- View tweakers
- Explicit keys for views
- Single/multiselect switch for listview
- Column selection feedback for listview
- Persistent sort for listview
- Keyboard input
- Focus direction
- Standard message dialogs
- Exception class hierarchy and reporting
- Moved to IronPython beta 7
- File selection dialog for multiple files, multiple extensions, function rather than class
- New tutorial programs added, especially for new features
- Bug fixes
- Significant performance enhancements, especially with selection in listview


Most important changes from wave-0.1-alpha-2 to wave-0.1-alpha-3:

- Adaptions to changes in Eden.


Known bugs
==========

External drag and drop format incompatible with external cut and paste format.


Installation
============

Step 1
------

Download and unpack Eden and Wave.
Read the licence.


Step 2
------

If needed, move Eden and Wave to create the following directory structure:

<any directory>
	QQuick
		eden-0.1-alpha-3
		wave-0.1-alpha-3

Step 3
------

Set the following enviroment variables:

qqEdenPath='<any directory>\qQuick\eden-0.1-alpha-3'
qqWavePath='<any directory>\qQuick\wave-0.1-alpha-3'

<any directory> is the same path as in step 2, e.g. C:\experimental_stuff.
Note than backslashes are to be used.


Step 4
------

Copy and paste the following lines into the file site.py, that is part of your IronPython installation:
(Alter to contain correct path of CPython according to your installation)


# -- Start of lines to copy and paste

import sys

sys.path.append ('C:/python24/lib')
sys.path.append ('C:/python24/libs')

import os

sys.path.insert (0, os.environ ['qqEdenPath'].replace ('\\', '/'))
sys.path.insert (1, os.environ ['qqWavePath'].replace ('\\', '/'))

# -- End of lines to copy and paste


Step 5
------

Go the Eden demo directory and type:

C:\IronPython-1.0-Beta7\IronPythonConsole demo.py
(Alter to contain correct path of IronPython according to your installation)

To fully benefit from the Wave (as opposed to Eden) demo, including truly performing example computations and viewing the results with GNUPlot, you will have to:

- Compile and link the C++ files into separate exe's and place them in the repertoire directory.
- Download and install GNUPlot.
- Start GNUPoll with the appropriate parameters (documentation to come).

Advice: Start with the Eden demo, since it is easiest to do.
Eden is independent of Wave and will enable you to very quickly write applications, once you got hold of its principles.
After you've tried the demo, take a look at the (yet tiny and very incomplete) series of examples in the tutorial directory.
The number of examples is planned to be expanded soon, but even these first tiny programs, together with the demo, may be enough to get you started.


Future
======

Plans are to build out and fully document Eden and Wave and stay committed to them for a long time to come.
They are the result of 25 years of programming and design experience and represent the way I think certain ever reoccuring problems in developing applications should be handled.

However not any, even implied guarantee is made with respect to their continuity.
Time will have to prove whether they acquire mindshare.

Currently Eden and Wave are a Windows only affair.
Porting view.py (and a very limited amount of other stuff) would make it multiplatform.
The way to go may be either Mono, or WxPython.


Enjoy!
Jacques de Hooge
info@geatec.com
