# ====== Legal notices
#
# Copyright (C) 2012, 2013 GEATEC engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.
#
# The QQuickLicense can be accessed at: http://www.geatec.com/qqLicence.html



# ====== Purpose
#
# This program gives a live demo of Gauss-Jordan elimination, also called sweeping, by showing intermediate results
# Each time type [enter] to go to the next step

# === Function example is called at the bottom of this file

def example ():
	original = [
		[1.0, 2.0, 3.0],
		[-10., 3.0, 4.0],
		[9.0, -4.0, 7.0]
	]
		
	print 'Original matrix:\n\n', original

	inverse = invert (original)

	print 'Inverse matrix:\n\n', inverse

	product = multiply (original, inverse)

	print 'Product of original and inverse is unity matrix:\n\n', product

	raw_input ('Example finished')

# === And this is wat it takes to make it work
	
from copy import deepcopy
	
def multiply (a, b):	# Overload * operator
	result = []
	
	# First make a zero matrix
	for iRow in range (len (a)):	# For all rows in a
		row = []
		for iColumn in range (len (b [0])):	# For all columns in b
			row.append (0.0)
		result.append (row)
		
	# Then that zero matrix as target for the multiplication
	for iRow in range (len (result)):		# For each iRow of the result matrix
		for iColumn in range (len (result [0])):	# For each iColumn of result matrix
			for iTerm in range (len (a [0])):	# Compute dot product of iRow'th rowvector of self and iColumn'th columnvector of other
				result [iRow][iColumn] += a [iRow][iTerm] * b[iTerm][iColumn]
				
	return result
			
			
def invert (a):	# Overload ** operator
	raw_input ('Start computing inverse, press return each time to go to the next step\n\n')
	raw_input ('Copy matrix:\n\n')
	a = deepcopy (a)
	print a
	print
	
	raw_input ('Augment matrix with unity matrix to the right:\n\n')
	for iRow in range (len (a)):
		for iColumn in range (len (a [0])):
			if iColumn == iRow:
				a [iRow] .append (1.0)
			else:
				a [iRow] .append (0.0)
	print a
	print
	
	print 'Use each row of the matrix as pivot row\n'
	for iPivot in range (len (a)):
		raw_input ('Make pivot element 1:\n\n')
		pivot = a [iPivot][iPivot]
		for iColumn in range (len (a [0])):
			a [iPivot][iColumn] /= pivot
		print a
		print
			
		raw_input ('Sweep rows below pivot row to get all zeroes in pivot column:\n\n')
		for iRow in range (iPivot + 1, len (a)):
			multiplier = a [iRow][iPivot]
			for iColumn in range (len (a [0])):
				a [iRow][iColumn] -= multiplier * a [iPivot][iColumn]
		print a
		print
				
	print 'Left matrix is now in upper triangular form\n'
	
	print 'Use each row except first one as pivot row\n'
	for iPivot in range (1, len (a)):
		raw_input ('Sweep rows above pivot row to get all zeroes in pivot column:\n\n')
		for iRow in range (iPivot):
			multiplier = a [iRow][iPivot]
			for iColumn in range (len (a [0])):
				a [iRow][iColumn] -= multiplier * a [iPivot][iColumn]
		print a
				
	print 'Left matrix is now unity matrix, right matrix is inverse\n' 

	raw_input ('Chop of left matrix, keep right matrix:\n\n')
	for iRow in range (len (a)):
		a [iRow] = a [iRow][len (a):]
	print a
	print
		
		
		
	return a
		
# ====== Run the example function	defined at the start of this source file	
	
example ()
