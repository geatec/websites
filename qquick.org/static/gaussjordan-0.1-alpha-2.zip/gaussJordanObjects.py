# ====== Legal notices
#
# Copyright (C) 2012, 2013 GEATEC engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.
#
# The QQuickLicense can be accessed at: http://www.geatec.com/qqLicence.html



# ====== Purpose
#
# This program gives a live demo of Gauss-Jordan elimination, also called sweeping, by showing intermediate results
# Each time type [enter] to go to the next step



# ====== Example of usage of Matrix class, called at the bottom of this source file

def example ():
	original = Matrix ([
		[1, 2, 3],
		[-1, 3, 4],
		[9, -4, 7]
	])
	print 'Original matrix:\n\n', original

	inverse = original ** -1	# a ** b means raise a to the b'th power
	print 'Inverse matrix:\n\n', inverse

	product = original * inverse
	print 'Product of original and inverse is unity matrix:\n\n', product

	raw_input ('Example finished')


	
# ====== Matrix class capable of multiplication and inversion	

from copy import *
	
class Matrix:
	def __init__ (self, *params):	# Constructor
		if len (params) == 2:	# Assume params are matrix dimensions
			self.elements = [[0. for column in range (params [1])] for row in range (params [0])] # Make a zero matrix
		else:					# Assume params are matrix elements (a list of lists)
			self.elements = [[float (element) for element in row] for row in params [0]]	# Convert to float, to prevent integer division
		self.nRows = len (self.elements)
		self.nColumns = len (self.elements [0]) if self.nRows else 0
		
	def __getitem__ (self, index):	# Make it possible to write   row =  matrix [r]   rather than   matrix.elements [r]
		return self.elements [index]
		
	def __setitem__ (self, index, value):	# Make it possible to write   matrix [r] = row   rather than   maatrix.elements [r] = row
		self.elements [index] = value
		
	def __mul__ (self, other):	# Overload * operator
		if self.nColumns == other.nRows:
			result = Matrix (self.nRows, other.nColumns)	# Instantiate zero result matrix
			for iRow in range (result.nRows):		# For each iRow of the result matrix
				for iColumn in range (result.nColumns):	# For each iColumn of result matrix
					for iTerm in range (self.nColumns):	# Compute dot product of iRow'th rowvector of self and iColumn'th columnvector of other
						result [iRow][iColumn] += self [iRow][iTerm] * other[iTerm][iColumn]
			return result
		else:
			raw_input ('Non matching dimensions')
			exit (1)
			
	def __pow__ (self, exponent):	# Overload ** operator
		if exponent == -1:
			raw_input ('Start computing inverse, press return each time to go to the next step\n\n')
			if self.nRows == self.nColumns:
				raw_input ('Copy matrix:\n\n')
				self = deepcopy (self)
				print self
				
				raw_input ('Augment matrix with unity matrix to the right:\n\n')
				for iRow in range (self.nRows):
					self [iRow] += [1. if iColumn == iRow else 0. for iColumn in range (self.nColumns)]
				self.nColumns *= 2
				print self
				
				print 'Use each row of the matrix as pivot row\n'
				for iPivot in range (self.nRows):
				
					raw_input ('Make pivot element 1:\n\n')
					pivot = self [iPivot][iPivot]
					for iColumn in range (self.nColumns):
						self [iPivot][iColumn] /= pivot
					print self
						
					raw_input ('Sweep rows below pivot row to get all zeroes in pivot column:\n\n')
					for iRow in range (iPivot + 1, self.nRows):
						multiplier = self [iRow][iPivot]
						for iColumn in range (self.nColumns):
							self [iRow][iColumn] -= multiplier * self [iPivot][iColumn]
					print self
							
				print 'Left matrix is now in upper triangular form\n'
				
				print 'Use each row except first one as pivot row\n'
				for iPivot in range (1, self.nRows):
				
					raw_input ('Sweep rows above pivot row to get all zeroes in pivot column:\n\n')
					for iRow in range (iPivot):
						multiplier = self [iRow][iPivot]
						for iColumn in range (self.nColumns):
							self [iRow][iColumn] -= multiplier * self [iPivot][iColumn]
					print self
							
				print 'Left matrix is now unity matrix, right matrix is inverse\n' 

				raw_input ('Chop of left matrix, keep right matrix:\n\n')
				for iRow in range (self.nRows):
					self [iRow] = self [iRow][self.nRows:]
				self.nColumns /=2
				print self
					
				return self
				
			else:
				raw_input ('No square matrix')
				exit (1)
		else:
			raw_input ('Only can raise matrix to power -1')
			exit (1)

	def __str__ (self):	# Define string representation of matrix
		s = ''
		for row in self.elements:
			for element in row:
				s += '{: 7.2f}'.format (element) # blank = - or blank, 7 = width, 3 = decimals, f = fixed point
			s += '\n'
		s += '\n'
		return s

		
		
# ====== Run the example function	defined at the start of this source file	
	
example ()
