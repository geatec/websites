# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from wave.xml import *
from wave.map import *

try:
	dataMap = DataMap ()

	dataMap.registerRun (
		'processorX',
		[
		],
		[
			('slotInA', ['kindInA0.nameInA0', 'kindInA1.nameInA1']),
			('slotInB', ['kindInB0.nameInB0', 'kindInB1.nameInB1'])
		],
		Run.Full
	)

	dataMap.registerRun (
		'processorY',
		[
			('slotInA', ['kindInA0.nameInA0', 'kindInA1.nameInA1']),
			('slotInB', ['kindInB0.nameInB0', 'kindInB1.nameInB1'])
		],
		[
			('slotOutC', ['kindOutC0.nameOutC0', 'kindOutC1.nameOutC1']),
			('slotOutD', ['kindOutD0.nameOutB0', 'kindOutD1.nameOutD1'])
		],
		Run.Full
	)

	dataMap.save ('dataMapUnitTest.xml')

	dataMap2 = DataMap ()
	dataMap2.load ('dataMapUnitTest.xml')
	dataMap2.save ('dataMap2UnitTest.xml')
	
	dataMap3 = dataMap2.clone ()
	dataMap3.save ('dataMap3UnitTest.xml')
	
except Refusal, refusal:
	handleNotification (refusal)
