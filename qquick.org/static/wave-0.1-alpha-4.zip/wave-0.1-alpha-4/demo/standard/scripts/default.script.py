from connector import *

def script ():
	pass

	producers__rampgenerator (
		nrOfSamples = 100,
		startIndex = 20,
		startValue = -10.0,
		stopIndex = 80,
		stopValue = 8.0,
		outputSignal = ['term1:vector/time/voltage:']
	)
	
	producers__rampgenerator (
		nrOfSamples = 100,
		startIndex = 20,
		startValue = -5.0,
		stopIndex = 80,
		stopValue = 5.0,
		outputSignal = ['term2:vector/time/voltage:']
	)
	
	transformers__adder (
		inputSignal1 = ['term1:vector/time/voltage:'],
		inputSignal2 = ['term2:vector/time/voltage:'],
		outputSignal = ['sum:vector/time/voltage:']
	)
	
	transformers__amplifier (
		amplification = '-1.0',
		inputSignal = ['sum:vector/time/voltage:'],
		outputSignal = ['product:vector/time/voltage:']
	)
	
	consumers__plotter (
		plotList = ['product:vector/time/voltage:', 'sum:vector/time/voltage:', 'term1:vector/time/voltage:', 'term2:vector/time/voltage:'],
		plotName = ['default:plot:']
	)

executeScript (script)
