import sys

sys.path.extend ([
	'C:/activ_dell/prog/qQuick/wave-0.1-alpha-3/demo/standard',
	'C:/activ_dell/prog/qQuick/wave-0.1-alpha-3/demo/repertoire'
])

from executor import *
