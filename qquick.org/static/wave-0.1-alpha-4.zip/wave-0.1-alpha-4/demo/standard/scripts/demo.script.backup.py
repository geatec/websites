from connector import *

def script ():
	pass

	producers__rampgenerator (
		nrOfSamples = 100,
		startIndex = 20,
		startValue = -5.0,
		stopIndex = 80,
		stopValue = 8.0,
		outputSignal = ['ramp1:vector:']
	)
	
	producers__rampgenerator (
		nrOfSamples = 100,
		startIndex = 20,
		startValue = 10.0,
		stopIndex = 80,
		stopValue = 8.0,
		outputSignal = ['ramp2:vector:']
	)
	
	transformers__adder (
		inputSignal1 = ['ramp1:vector:'],
		inputSignal2 = ['ramp2:vector:'],
		outputSignal = ['summed:vector:']
	)
	
	transformers__amplifier (
		amplification = -1.0,
		inputSignal = ['summed:vector:'],
		outputSignal = ['multiplied:vector:']
	)
	
	consumers__plotter (
		plotList = ['ramp1:vector:', 'ramp2:vector:', 'summed:vector:', 'multiplied:vector:'],
		plotName = ['default:plot:']
	)
	

executeScript (script)