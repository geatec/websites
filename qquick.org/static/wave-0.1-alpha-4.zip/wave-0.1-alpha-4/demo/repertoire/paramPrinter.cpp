/*
# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.
*/

#include <iostream>

using namespace std;

void main (int argCount, char *argVec []) {
	cout << "[Start of args]" << endl;
	for (int argIndex = 0; argIndex < argCount; argIndex++) {
		cout << argVec [argIndex] << endl;
	}
	cout << "[End of args]" << endl;
	
	char dummy;
	cin >> dummy;
}
