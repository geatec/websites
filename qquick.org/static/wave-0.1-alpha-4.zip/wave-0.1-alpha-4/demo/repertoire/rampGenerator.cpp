/*
# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.
*/

#include <fstream>
#include <stdlib.h>
#include <string>

using namespace std;

void main (int argCount, char *argVec []) {
	int nrOfSamples = atoi (argVec [1]);
	int startIndex = atoi (argVec [2]);
	float startValue = atof (argVec [3]);
	int stopIndex = atoi (argVec [4]);
	float stopValue = atof (argVec [5]);
	string outputSignal = argVec [6];

	int deltaIndex = stopIndex - startIndex;
	float deltaValue = stopValue - startValue;
	float slope = deltaValue / deltaIndex;

	ofstream outputSignalFile (outputSignal.c_str ());

	for (int sampleIndex = 0; sampleIndex < nrOfSamples; sampleIndex++) {
		if (sampleIndex < startIndex) {
			outputSignalFile << startValue << endl;
		}
		else if (sampleIndex < stopIndex) {
			outputSignalFile << startValue + slope * (sampleIndex - startIndex) << endl; 
		}
		else {
			outputSignalFile << stopValue << endl;
		}
	}
}
