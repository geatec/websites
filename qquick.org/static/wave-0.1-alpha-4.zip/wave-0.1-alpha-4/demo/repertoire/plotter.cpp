/*
# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.
*/

#include <stdlib.h>

#include <iostream>

#include <fstream>
#include <string>
#include <list>
#include <algorithm>

using namespace std;

string getArgument (ifstream &file) {
	const int BufferSize = 1024;
	char buffer [BufferSize];

	file.getline (buffer, BufferSize);

	char *strippedBuffer = buffer;

	while (*strippedBuffer == '\t') {
		strippedBuffer++;
	}

	return string (strippedBuffer);
}

void main (int argCount, char *argVec []) {
	char* runId = argVec [1];
	char* argumentFileName = argVec [2];
	char* reportFileName = argVec [3];

	ifstream argumentFile (argumentFileName);
	ofstream reportFile (reportFileName);

	string argument;
	list <string> plottableFileNames;

	while (getArgument (argumentFile) .find ("<plotList>") == string::npos);

	bool success = true;

	while ((argument = string (getArgument (argumentFile))) .find ("</plotList>") == string::npos) {
		if (argument.find ("failure") != string::npos) {
			success = false;
		}

		plottableFileNames.push_back (argument);
	}

	while (getArgument (argumentFile) .find ("<plotName>") == string::npos);

	ofstream plotFile (getArgument (argumentFile) .c_str ());

	plotFile << "plot [0:100] [-20:20] 0" << endl;

	while (plottableFileNames.size ()) {
		plotFile << "replot \"" << * (plottableFileNames.begin ()) << "\" with lines" << endl;
		plottableFileNames.pop_front ();
	}

	reportFile << "<runId>" << endl;
	reportFile << "\t" << runId << endl;
	reportFile << "</runId>" << endl;

	reportFile << "<result>" << endl;

	if (success) {
		reportFile << "\tsuccess" << endl;
	}
	else {
		reportFile << "\tfailure" << endl;
	}

	reportFile << "</result>" << endl;

    argumentFile.close ();
	_unlink (argumentFileName);
}
