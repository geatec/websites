/*
# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.
*/

#include <fstream>
#include <stdlib.h>
#include <string>

using namespace std;

void main (int argCount, char *argVec []) {
	string inputSignal1 = argVec [1];
	string inputSignal2 = argVec [2];
	string outputSignal = argVec [3];

	ifstream inputSignalFile1 (inputSignal1.c_str ());
	ifstream inputSignalFile2 (inputSignal2.c_str ());
	ofstream outputSignalFile (outputSignal.c_str ());

	while (inputSignalFile1 && inputSignalFile2) {
		float sample1, sample2;
		inputSignalFile1 >> sample1;
		inputSignalFile2 >> sample2;
		outputSignalFile << sample1 + sample2 << endl;
	}
}
