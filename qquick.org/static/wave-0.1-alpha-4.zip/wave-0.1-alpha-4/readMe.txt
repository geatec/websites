# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.


Purpose
=======

QQuick currently consists of two parts:

1. Eden (Event Driven Evaluation Nodes)

Eden is a library that allows rapid construction of applications with the following internal characteristics:

- Interdependencies between variables are captured by the Event Driven Evaluation Node pattern. This is a highly improved version of the wellknown Observer pattern, allowing cyclic dependencies, rollback and caching.
- GUI's are constructed by nesting Views (see demo and tutorials). Layout management is automatic. All dialogs are scalable.
- Full drag and drop support, including drag and drop reordering is enabled for lists and trees. 
- Both data and layout are persistent.


2. Wave (Wave Activated Versioning Engine)

Wave is an application framework for turning a set of bare bones command line computational programs into a datacentric, scriptable GUI-application with full datalineage management and automatic recomputation at parameter changes.

Wave is also a quite elaborated example of how to use and benefit from the Eden library.


System requirements
===================

Windows XP
DotNet 2.0 + SDK
IronPython 1.0
Python 2.5 (CPython, that is)


Status
======

Eden is stable and has been used for production programming for over a year now by several people.
The set of Views is expected to grow, e.g. with 2D and 3D graphical views.
If you build an app with the current viewset, it's unlikely you'll have to change much for the final version.

Wave is still incomplete, in flux and lacks the use of modules.
Due to intense work on Eden, development on Wave has temporarily halted.
The demo is worth trying, as it illustrates the underlying concepts.
The unittests lag back, hence are currently to be considered broken.

Documentation is sorely missing. It will be added gradually. Priority will be given to document Eden.


Recent changes
==============

Most important changes from eden-0.1-alpha-3 to eden-0.1-beta-1:

- In place editing, column hiding and some new constructor parameters for ListViews.
- Addition of a simple HTML browser to the panel.py.
- Addition of toolbars. 
- Improved event handling, action and rollback logic for Nodes.
- Refinement of the module mechanism.
- Many small refinements and fixes, as Eden has been used to commercially develop two engineering applications.
- Addition of a simple icon collection.
- XML configuration files.

Most important changes from wave-0.1-alpha-3 to wave-0.1-alpha-4:

- Adaptions to changes in Eden.


Known bugs
==========

External drag and drop format incompatible with external cut and paste format.


Installation
============

Step 1
------

Download and unpack Eden and Wave.
Read the licence.


Step 2
------

If needed, move Eden and Wave to create the following directory structure:

<any directory>
	QQuick
		eden-0.1-beta-1
		wave-0.1-alpha-4

Step 3
------

Set the following enviroment variables:

qqEdenPath='<any directory>\qQuick\eden-0.1-beta-1'
qqWavePath='<any directory>\qQuick\wave-0.1-alpha-4'
qqPythonInterpreter='C:\IronPython-1.0\ipy.exe'

<any directory> is the same path as in step 2.
Note than backslashes are to be used.


Step 4
------

Copy and paste the following lines into the file ..\Lib\site.py, that is part of your IronPython installation:


# -- Start of lines to copy and paste

import sitecustomize

# -- End of lines to copy and paste


Create a file sitecustomize.py in directory ..\Lib and copy and paste to it the following contents:

(Alter to contain correct path of CPython according to your installation)


# -- Start of lines to copy and paste

import sys

sys.path.append ('C:/python25/lib')
sys.path.append ('C:/python25/libs')

import os

sys.path.insert (0, os.environ ['qqEdenPath'].replace ('\\', '/'))
sys.path.insert (1, os.environ ['qqWavePath'].replace ('\\', '/'))

QqPlatform = ['IronPython', 'WinForms']

# -- End of lines to copy and paste


Step 5
------

Go the Eden demo directory and type:

C:\IronPython-1.0\ipy demo.py
(Alter to contain correct path of IronPython according to your installation)

To fully benefit from the Wave (as opposed to Eden) demo, including truly performing example computations and viewing the results with GNUPlot, you will have to:

- Compile and link the C++ files into separate exe's and place them in the repertoire directory.
- Download and install GNUPlot.
- Start GNUPoll with the appropriate parameters (documentation to come).

Advice: Start with the Eden demo, since it is easiest to do and Eden is already quite stable.
Eden is independent of Wave and will enable you to quickly write maintainable applications, once you got hold of its principles.
After you've tried the demo, take a look at the (yet tiny and very incomplete) series of examples in the tutorial directory.
The number of examples is planned to be expanded soon, but even these first tiny programs, together with the demo, may be enough to get you started.


Future
======

Plans are to build out and fully document Eden and Wave and stay committed to them for a long time to come.
However not any, even implied guarantee is made with respect to their continuity.
Time will have to prove whether they acquire mindshare.

There exists a proprietary commercial port of Eden to Qt using PyQt.
It runs on Linux and Windows and is owned by a third party.
It is not available as open source software, but its existence has proven the portability of Eden.

Currently the free versions of Eden and Wave are a Windows only affair.
Porting view.py, panel.py, platform.py and tweakers.py is all that is needed to reach other platforms.
The way to go for free versions may be either Mono, or WxPython.


Enjoy!
Jacques de Hooge
info@geatec.com
