# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from re import *

from config import *
from eden import *
from waveLib.platform import *
from waveLib.map import *
from waveLib.shop import *
from waveLib.processor import *
from waveLib.recorder import *
from repertoire import *

class DataManager:
	def __init__ (self):
	
		# --- Preparatory
		
		dataMapGuard = FileGuard (application.ProjectDirectory + '/current.dataMap')
	
		# --- Export nodes
		
		self.itemListNode = Node ()
		self.selectedItemListNode = Node ([])
				
		self.explorationDepthNode = application.store.add (Node (2))
		self.backNode = Node (None)
		self.forwardNode = Node (None)
		
		self.doFocusItemListNode = Node (None)
		self.focusedItemListNode = application.store.add (Node ([]))
		
		self.doOpenShopNode = Node (None)
		self.doProcessorsDialogNode = Node (None)
		
		# --- Local nodes
		
		isItemSelectionMadeNode = Node ()
		isSingleItemSelectionMadeNode = Node ()
		
		useItemFilterNode = application.store.add (Node (True))
		
		doDeleteItemsDialogNode = Node (None)
		doExitDeleteNode = Node (None)
		doApplyAndExitDeleteNode = Node (None)
			
		processorTreeNode = Node ()
		selectedProcessorPathNode = Node ([])	
		doShowProcessorNode = Node (None)
		
		doShowItemProcessorsNode = Node (None)
			
		doRecorderDialogNode = Node (None)
		
		doReloadDataMapNode = Node (None)
	
		doCrowdDataMapNode = Node (None)
	
		# --- Importers

		ancestorTree = AncestorTree (self)
		descendantTree = DescendantTree (self)
			
		itemWorkshop = ItemWorkshop (self)
		
		# --- Dependencies
					
		def transactDataMap ():
			
			# --- Deal with possible dependent initialisation transaction
		
			try:																# Regular transaction
				newDataMap = application.dataMapNode.old.clone ()
			except:																# Dependent initialization
				newDataMap = DataMap ()
				
				try:
					dataMapGuard.request (True)
					newDataMap.load (dataMapGuard.lockedFileName)
					dataMapGuard.release ()
				except:
					newDataMap.load (application.ProjectDirectory + '/templates.dataMap')
					newDataMap.save (dataMapGuard.originalFileName)
					dataMapGuard.update ()
					
				return newDataMap

			# --- Regular transaction
			
			dataMapGuard.request (True)
			
			if itemWorkshop.doApplyCreateNode.touched:
				itemKeyList = [':'.join (itemKeyParts) for itemKeyParts in itemWorkshop.creationList.listNode.old]
				newDataMap.newWave ()
				newDataMap.registerRun ('builtIn/itemFactory', [], [('all', itemKeyList)], None, Run.Full)
			elif doApplyAndExitDeleteNode.touched:
				for itemKey in self.selectedItemListNode.old:
					newDataMap.removeItem (itemKey)
			elif application.repertoire.runTransactorNode.touched:
				application.repertoire.runTransactorNode.new (newDataMap)
			elif doReloadDataMapNode.touched:
				newDataMap.load (dataMapGuard.lockedFileName)
			else:
				pass
#				crowdDataMap (newDataMap)
				
			if not doReloadDataMapNode.touched:
				newDataMap.save (dataMapGuard.lockedFileName)
				
			dataMapGuard.release ()
			return newDataMap
		
		application.dataMapNode.dependsOn (
			[
				itemWorkshop.doApplyCreateNode,
				doApplyAndExitDeleteNode,
				application.repertoire.runTransactorNode,
				doReloadDataMapNode,
				doCrowdDataMapNode
			],
			transactDataMap
		)	
					
		def acceptable (itemKey):
			producerRun = application.dataMapNode.new.items [itemKey].outputSlot.run
			
			def match (compiledItem):
				for aspect in range (Item.NrOfAspects):
					if aspect < Item.ProcessorName:
						aspectPath = itemKey.rsplit (':' ,2) [aspect]
					elif aspect == Item.ProcessorName:
						aspectPath = producerRun.processorName
					else:
						aspectPath = producerRun.runKey
						
					if not compiledItem [aspect] .match (aspectPath):
						return False

				return True
		
			if useItemFilterNode.new:
				for compiledExclusionItem in itemWorkshop.compiledExclusionListNode.new:
					if match (compiledExclusionItem):
						return False
						
				if len (itemWorkshop.compiledInclusionListNode.new):
					for compiledInclusionItem in itemWorkshop.compiledInclusionListNode.new:
						if match (compiledInclusionItem):
							return True
					else:
						return False
				else:
					return True
			else:
				return True
				
		self.itemListNode.dependsOn (
			[application.dataMapNode, itemWorkshop.doApplyFilterNode, useItemFilterNode],
			lambda: sorted ([itemKey for itemKey in application.dataMapNode.new.items if acceptable (itemKey)])
		)

		self.selectedItemListNode.dependsOn (
			[self.itemListNode, self.focusedItemListNode],
			lambda: ifCall (
				self.itemListNode.touched,
				itemListView.interestingItemList,
				lambda: self.focusedItemListNode.new
			)
		)
		
		isItemSelectionMadeNode.dependsOn ([self.selectedItemListNode], lambda: len (self.selectedItemListNode.new) > 0)
		isSingleItemSelectionMadeNode.dependsOn ([self.selectedItemListNode], lambda: len (self.selectedItemListNode.new) == 1)
		
		def getFocusedItemList (): # ??? Length checks?
			if self.doFocusItemListNode.touched:
				return [self.selectedItemListNode.old [0]]
			elif ancestorTree.doFocusNode.touched:
				return [ancestorTree.selectedPathNode.old [len (ancestorTree.selectedPathNode.old) - 1]]
			elif descendantTree.doFocusNode.touched:
				return [descendantTree.selectedPathNode.old [len (descendantTree.selectedPathNode.old) - 1]]
			elif doApplyAndExitDeleteNode.touched and len (self.selectedItemListNode.new):
				return [self.selectedItemListNode.new [0]]
			else:
				return []

		self.focusedItemListNode.dependsOn (
			[self.doFocusItemListNode, ancestorTree.doFocusNode, descendantTree.doFocusNode, doApplyAndExitDeleteNode],
			getFocusedItemList
		)
		
		processorTreeNode.dependsOn ([], application.repertoire.getProcessorTree)
		
		doExitDeleteNode.dependsOn ([doApplyAndExitDeleteNode], lambda: None)		
					
		# --- Views

		controlView = HGridView ([
			ButtonView (self.backNode, icon = 'leftArrow', hint = 'Back'),
			ButtonView (self.forwardNode, icon = 'rightArrow', hint = 'Forward'),
			FillerView (),
			RLabelView ('Exploration Depth'),
			HExtensionView (), HExtensionView (),
			DeltaView (self.explorationDepthNode, hint = 'Available generations per tree')
		])
				
		def transform (itemKey, columnIndex = -1):		
			transformedItem = [None for aspect in range (Item.NrOfAspects)]
			
			all = columnIndex == -1

			splitItemKey = itemKey.rsplit (':', 2)
			for aspect in range (Item.ProcessorName):
				if all or columnIndex == aspect:
					transformedItem [aspect] = splitItemKey [aspect]

			if all or columnIndex in (Item.ProcessorName, Item.RunKey):
				producerRun = application.dataMapNode.new.items [itemKey].outputSlot.run
				
				if all or columnIndex == Item.ProcessorName:
					transformedItem [Item.ProcessorName] = producerRun.processorName
					
				if all or columnIndex == Item.RunKey:
					transformedItem [Item.RunKey] = producerRun.runKey
			
			return transformedItem			
		
		itemListView = ListView (
			listNode = self.itemListNode,
			columnLabels = Item.AspectNames,
			selectedListNode = self.selectedItemListNode,
			transformer = transform,
			contextMenuView = ContextMenuView ([
				MenuButtonView (
					actionNode = doShowItemProcessorsNode,
					caption = 'Show Processors that created Items',
					enabled = isItemSelectionMadeNode
				),
				MenuButtonView (
					actionNode = self.doFocusItemListNode,
					caption = 'Focus on Item',
					enabled = isSingleItemSelectionMadeNode
				),
				MenuButtonView (
					actionNode = doDeleteItemsDialogNode,
					caption = 'Delete Items',
					enabled = isItemSelectionMadeNode
				),
				MenuButtonView (
					actionNode = itemWorkshop.doUseAsShopExpressionNode,
					caption = 'Use in Item Workshop',
					enabled = isSingleItemSelectionMadeNode
				)
			]),
			dragObjectGetter = lambda: self.selectedItemListNode.new
		)
						
		deleteItemsView = ModalView (
			VGridView ([
				FillerView (),
				CLabelView ('The selected Items will be deleted permanently. Are you sure you want that?'),
				HGridView ([
					FillerView (), FillerView (),
					ButtonView (
						 doApplyAndExitDeleteNode,
						'Yes'
					),
					ButtonView (
						doExitDeleteNode,
						'No'
					),
					FillerView (), FillerView ()
				])
			]),
			'Delete Items'
		)
					
		processorsView = ModelessView (
			TreeView (
				treeNode = processorTreeNode,
				selectedPathNode = selectedProcessorPathNode,
				contextMenuView = ContextMenuView ([
					MenuButtonView (
						actionNode = doShowProcessorNode,
						caption = 'Show Processor'
					)
				])	
			),
			'Processor Repertoire'
		)
	
		self.clientView = HSplitView (
			VGridView ([
				HGridView ([
					LLabelView ('Item List'),
					CheckView (useItemFilterNode, 'Use Item Filter', hint = 'Apply current settings of Item Filter to reduce number of Items shown in Item List'),
					HExtensionView ()
				]),
				itemListView
			]),
			VGridView ([
				VSplitView (
					VGridView ([
						LLabelView ('Ancestor Tree'),
						ancestorTree.view
					]),
					VGridView ([
						LLabelView ('Descendant Tree'),
						descendantTree.view,
					])
				),
				controlView
			])
		)
		
		self.menuBarView = MenuBarView ([
			MenuButtonView (self.doOpenShopNode, 'Item Workshop'),
			MenuButtonView (self.doProcessorsDialogNode, 'Processor Repertoire'),
			MenuButtonView (doRecorderDialogNode, 'Script Recorder')
		])

		# --- Actions
		
		doDeleteItemsDialogNode.action = deleteItemsView.execute
		doExitDeleteNode.action = deleteItemsView.exit
		
		self.doOpenShopNode.action = itemWorkshop.view.execute			
		
		self.doProcessorsDialogNode.action = processorsView.execute
		doShowProcessorNode.action = lambda: application.repertoire.showProcessorEmpty ('/'.join (selectedProcessorPathNode.new))
		
		def showItemProcessors ():
			for itemKey in self.selectedItemListNode.old:
				item = application.dataMapNode.old.items [itemKey]
				application.repertoire.showProcessorRun (application.dataMapNode.old, item.outputSlot.run.runKey)
		
		doShowItemProcessorsNode.action = showItemProcessors
		
		doRecorderDialogNode.action = application.scriptRecorder.view.execute

		# --- Start polling

		self.intervalTimer = IntervalTimer ()
		
		def poll ():
			if dataMapGuard.modified ():
				doReloadDataMapNode.change (None, True)	
				
		self.intervalTimer.addCallBack (2, lambda: poll ())
					
# --- Define FamilyTree classes

class FamilyTree:
	def __init__ (self, dataManager):
	
		# --- Transit non-nodes
		
		self.dataManager = dataManager	# Transit to getBranch specialistions in descendant classes
			
		# --- Export nodes
		
		self.selectedPathNode = Node ([])
		self.doFocusNode = Node (None)
		
		# --- Local nodes
		
		treeNode = Node ([])
		
		# --- Depencencies
	
		def getTree ():
			if len (dataManager.focusedItemListNode.new):
				return [self.getBranch (application.dataMapNode.new.items [dataManager.focusedItemListNode.new [0]], 1)]
			else:
				return []
				
		treeNode.dependsOn ([application.dataMapNode, dataManager.focusedItemListNode, dataManager.explorationDepthNode], getTree)
		
		# --- Views
		
		def transform (itemKey):
			if itemKey == dataManager.focusedItemListNode.new [0]:
				usedPrefix = ''
			else:
				usedPrefix = self.prefix + ':   '
			
			return usedPrefix +	' : '.join (itemKey.rsplit (':', 2))
				
		self.view = TreeView (
			treeNode = treeNode, 
			selectedPathNode = self.selectedPathNode,
			expansionLevel = dataManager.explorationDepthNode,
			contextMenuView = ContextMenuView ([MenuButtonView (self.doFocusNode, 'Focus')]),
			transformer = transform
		)		
	
class AncestorTree (FamilyTree):
	def __init__ (self, dataManager):
		self.prefix = 'Derived from'
		FamilyTree.__init__ (self, dataManager)
		
	# --- Specialisations

	def getBranch (self, item, depth):
		if depth < self.dataManager.explorationDepthNode.new and len (item.outputSlot.run.inputSlots):
			branch = (item.itemKey, [])
			for inputSlot in item.outputSlot.run.inputSlots:
				for inputItem in inputSlot.items:
					branch [1] .append (self.getBranch (inputItem, depth + 1))
			return branch
		else:
			return item.itemKey
	
class DescendantTree (FamilyTree):
	def __init__ (self, dataManager):
		self.prefix = 'Used for'
		FamilyTree.__init__ (self, dataManager)

	# --- Specialisations

	def getBranch (self, item, depth):
		if depth < self.dataManager.explorationDepthNode.new and len (item.inputSlots):
			branch = (item.itemKey, [])
			for inputSlot in item.inputSlots:
				for outputSlot in inputSlot.run.outputSlots:
					for outputItem in outputSlot.items:
						branch [1] .append (self.getBranch (outputItem, depth + 1))
			return branch
		else:
			return item.itemKey
			
# --- Starting up code
			
application.store = Store ()		
application.dataMapNode = Node ()
application.repertoire = Repertoire ()
application.scriptRecorder = ScriptRecorder ()

dataManager = DataManager ()
