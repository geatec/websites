# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from System import Diagnostics
from System import IO

#def fileExists (fileName):
#	try:
#		file = open (fileName, 'r')
#		file.close ()
#		return True
#	except:
#		return False

def copyFile (sourceName, destinationName):
	IO.File.Copy (sourceName, destinationName, True)

def deleteFile (fileName):
	IO.File.Delete (fileName)

class FileGuard:
	def __init__ (self, fileName):
		self.originalFileName = fileName
		self.lockedFileName = '__locked.'.join (fileName.rsplit ('.', 1))
		
	def update (self):
		self.lastModificationTime = IO.File.GetLastWriteTimeUtc (self.originalFileName)
		
	def request (self, wait):
		if wait:
			while (fileExists (self.lockedFileName)):
				pass
				
		print self.originalFileName, self.lockedFileName
		IO.File.Move (self.originalFileName, self.lockedFileName)
			
	def release (self):
		self.lastModificationTime = IO.File.GetLastWriteTimeUtc (self.lockedFileName)
		print self.lastModificationTime
		IO.File.Move (self.lockedFileName, self.originalFileName)
			
	def modified (self):														# !!! Encode access time in filename if os resolution to low
		try:
			return IO.File.GetLastWriteTimeUtc (self.originalFileName) .Ticks > self.lastModificationTime.Ticks
		except:																# Under modification
			return False
			
def execute (executable, arguments, wait):
	process = Diagnostics.Process ()
	process.StartInfo.FileName = executable
	process.StartInfo.Arguments = arguments
	process.Start ()
	
	if wait:
		process.WaitForExit ()
		return process.ExitCode
	
