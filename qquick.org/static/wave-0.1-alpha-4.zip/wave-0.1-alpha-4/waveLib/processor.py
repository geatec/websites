# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from config import *
from eden import *
from waveLib.platform import *
from waveLib.map import *
from waveLib.recorder import *

class BaseRepertoire:
	ExecutorName = 'executor.py'
		
	def __init__ (self):
		self.processorClasses = {}
		self.addProcessors ()
		self.generateExecutor ()
		self.runTransactorNode = Node (lambda dataMap: None)

	def generateExecutor (self):
		FullExecutorName = 	application.RepertoireDirectory + '/' + BaseRepertoire.ExecutorName
		
		if not fileExists (FullExecutorName):
			lines = []
			
			lines.append ('from repertoire import *')
			lines.append ('')
			
			lines.append ('application.repertoire = Repertoire ()')
			lines.append ('application.repertoire.addProcessors ()')
			lines.append ('')
									
			for processorName in self.processorClasses:
				processor = self.instantiateProcessor (processorName)
				processor.emitInstanceToExecutor (lines)
				processor.emitFunctionToExecutor (lines)
			
			file = open (FullExecutorName, 'w')
			file.write ('\n'.join (lines))
			file.close ()
			
	def instantiateProcessor (self, processorName):
		return self.processorClasses [processorName] (processorName)
		
	def printCanNotShowProcessorMessage (self, processorName):
		print 'Warning: Processor', processorName, 'can not be shown'

	def showProcessorEmpty (self, processorName):
		try:
			processor = self.instantiateProcessor (processorName)
			processor.show ()
		except:
			self.printCanNotShowProcessorMessage (processorName)
		
	def showProcessorRun (self, dataMap, runKey):
		try:
			processorName = dataMap.runs [runKey] .processorName
			processor = self.instantiateProcessor (processorName)
			processor.loadRun (dataMap, runKey)
			processor.show ()
		except:
			self.printCanNotShowProcessorMessage (processorName)
		
	def addProcessorClass (self, processorName, processorClass):
		self.processorClasses [processorName] = processorClass
		
	def getProcessorTree (self):
		self.processorTree = []

		for processorKey in self.processorClasses:				
			insertPath (self.processorTree, processorKey.rsplit ('/'))
				
		sortTree (self.processorTree)				
		return self.processorTree

class Processor:	
	def __init__ (self, processorName):
		self.processorName = processorName
		
		self.viewStore = Store ()
		
		self.paramStore = Store ()
		self.paramNames = []
		self.paramNodes = {}
		
		self.inputNames = []
		self.inputNodes = {}
		
		self.outputNames = []
		self.outputNodes = {}
				
		self.argumentNames = []
		self.argumentNodes = {}
		
	def defParam (self, name, value):
		node = Node (value)
		setattr (self, name + 'Node', node)
		self.paramStore.add (node, name)
		self.paramNodes [name] = node
		self.paramNames.append (name)
		self.argumentNames.append (name)
		self.argumentNodes [name] = node
		
	def defInput (self, name, value):
		value = getList (value)		# !!! No need for getList
		node = Node (value)
		setattr (self, name + 'Node', node)
		self.inputNodes [name] = node
		self.inputNames.append (name)
		self.argumentNames.append (name)
		self.argumentNodes [name] = node
		
	def defOutput (self, name, value):
		value = getList (value)
		node = Node (value)
		setattr (self, name + 'Node', node)
		self.outputNames.append (name)
		self.outputNodes [name] = node
		self.argumentNames.append (name)
		self.argumentNodes [name] = node
		
	processorId = property (lambda self: self.processorName.replace ('/', '__'))
	
	def getArgumentSeparator (self, argumentName):
		if argumentName == self.argumentNames [len (self.argumentNames) - 1]:
			return ''
		else:
			return ','
	 		
	def emitInstanceToExecutor (self, lines):
		lines.append (self.processorId + '__instance = instantiateProcessor (\'' + self.processorName + '\')')
		lines.append ('')
		
	def emitFunctionToExecutor (self, lines):
		lines.append ('def ' + self.processorId + ' (')

		for argumentName in self.argumentNames:
			lines.append ('\t' + argumentName + self.getArgumentSeparator (argumentName))

		lines.append ('):')

		for argumentIndes, argumentName in enumerate (self.argumentNames):
			lines.append ('\t' + self.processorId + '__instance.' + argumentName + 'Node.change (' + argumentName + ')')

		lines.append ('\t' + self.processorId + '__instance.scriptedRun ()')
		lines.append ('')
		
	def show (self):
		currentViewStore.value = self.viewStore
		
		doFullRunNode = Node (None)
		doFullRunNode.action = lambda: application.repertoire.runTransactorNode.follow (
			lambda dataMap: self.wave (dataMap = dataMap, updateLevel = Run.Full),
			True
		)
		
		doTrialRunNode = Node (None)
		doTrialRunNode.action = lambda: application.repertoire.runTransactorNode.follow (
			lambda dataMap: self.wave (dataMap = dataMap, updateLevel = Run.Trial),
			True
		)
		doTrialRunNode.action = lambda: None
		
		doDryRunNode = Node (None)
		doDryRunNode.action = lambda: application.repertoire.runTransactorNode.follow (
			lambda dataMap: self.wave (dataMap = dataMap, updateLevel = Run.Dry),
			True
		)
		
		doSaveViewStoreNode = Node (None)
		doSaveViewStoreNode.action = self.viewStore.save
		
		view = ModelessView (
			clientView = self.createView (),
			caption = self.processorName,
			
			menuBarView = MenuBarView ([
				MenuListView ([
					MenuButtonView (doFullRunNode, 'Full Run'),
					MenuButtonView (doTrialRunNode, 'Trial Run', enabled = False),
					MenuButtonView (doDryRunNode, 'Dry Run'),
				], 'Run'),
				MenuButtonView (doSaveViewStoreNode, 'Save Layout as Template')
			])
		)
		 
		self.viewStore.load (application.ProjectDirectory + '/' + self.processorId + '__views' + '.store')
		view.execute ()
		
	# --- Primitive run functions
	
	def registerRun (self, dataMap, updateLevel, owningWaveNr):
		inputSlots = [(inputName, self.inputNodes [inputName] .new) for inputName in self.inputNames]
		outputSlots = [(outputName, self.outputNodes [outputName] .new) for outputName in self.outputNames]
		
		return dataMap.registerRun (self.processorName, inputSlots, outputSlots, self.paramStore, updateLevel, owningWaveNr)
			
	def loadRun (self, dataMap, runKey):
		run = dataMap.runs [runKey]
	
		for inputSlot in run.inputSlots:
			self.inputNodes [inputSlot.slotName] .follow ([inputItem.itemKey for inputItem in inputSlot.items])

		for outputSlot in run.outputSlots:
			self.outputNodes [outputSlot.slotName] .follow ([outputItem.itemKey for outputItem in outputSlot.items])
				
		dataMap.loadParamStore (self.paramStore, runKey)		
	
	def emitLineToScript (self, line):
		application.scriptRecorder.emitLineToScript (line)
	
	def emitCallToScript (self):
		if application.scriptRecorder.stateNode.new == ScriptRecorder.Recording:
			self.emitLineToScript (self.processorId + ' (')
			for argumentName in self.argumentNames:
				self.emitLineToScript ('\t' + argumentName + ' = ' + str (self.argumentNodes [argumentName] .new) + self.getArgumentSeparator (argumentName))
			self.emitLineToScript (')')
			self.emitLineToScript ('')
		
	def compute (self, updateLevel, runKey):
		print 'Running', self.processorName
		
	# --- Compound run functions
		
	def insulatedRun (self, dataMap, updateLevel, owningWaveNr):
		runKey = self.registerRun (dataMap, updateLevel, owningWaveNr)		
		
		try:							# Interactive mode, recorder present, may or may not be recording
			self.emitCallToScript ()
		except:							# Executing script, no recorder present
			pass
			
		if updateLevel > Run.Dry:
			self.compute (updateLevel, runKey)
#			dataMap.runs [runKey] .updateLevel = updateLevel

		return runKey
	
	def wave (self, dataMap, updateLevel):
		dataMap.newWave ()

		try:
			self.insulatedRun (dataMap, updateLevel, 0)
			
			pendingRunKeys = dataMap.getPendingRunKeys (updateLevel)
			
			while len (pendingRunKeys):
				runKeysToRemove = []
				for runKey in pendingRunKeys:
					run = dataMap.runs [runKey]
					if run.inputsUpdated (updateLevel):
						processor = application.repertoire.instantiateProcessor (run.processorName)
						processor.loadRun (dataMap, runKey)			
						processor.insulatedRun (dataMap, updateLevel, 0)
						runKeysToRemove.append (runKey)
				if not len (runKeysToRemove):
					raise Error ('Can not update runs ' + str (pendingRunKeys)) 
				shrinkList (pendingRunKeys, runKeysToRemove, True)
				
		except RunError, runError:
			handleNotification (runError)
		
	def scriptedRun (self):
		if application.owningWaveNr:
			runKey = self.insulatedRun (application.dataMap, Run.Dry, application.owningWaveNr)
			application.scheduledRunKeyList.append (runKey)
		else:
			runKey = application.scheduledRunKeyList [application.scheduledRunKeyIndex]
			self.compute (application.updateLevel, runKey)
			application.completedRunKeyList.append (runKey)
			application.scheduledRunKeyIndex += 1

class RuleFileProcessor (Processor):
	def __init__ (self, processorName):
		Processor.__init__ (self, processorName)

	def getFileName (self, itemKey):
		return application.DataDirectory + '/' + itemKey.replace ('/', '!') .replace (':', '__') + '.data'

class StandardFileProcessor (RuleFileProcessor):
	def __init__ (self, processorName):
		Processor.__init__ (self, processorName)
		
	def getFileNames (self, itemList):
		return ' '.join ([self.getFileName (itemKey) for itemKey in itemList])
		
	def compute (self, updateLevel, runKey):
		if execute (self.getExecutable (), self.getArguments (), True) != 0:
			raise RunExecutionError (runKey)

class CustomFileProcessor (RuleFileProcessor):
	def __init__ (self, processorName):
		Processor.__init__ (self, processorName)
		
	def writeArguments (self, fileName):
		xmlWriter = XmlWriter ()
		xmlWriter.open (fileName)
		xmlWriter.writeOpenTag ('arguments')
		
		xmlWriter.writeOpenTag ('inputs')
		for inputName in self.inputNames:
			xmlWriter.writeOpenTag (inputName)
			for input in getattr (self, inputName + 'Node') .new:
				xmlWriter.writeField (self.getFileName (input))
			xmlWriter.writeCloseTag ()
		xmlWriter.writeCloseTag ()

		xmlWriter.writeOpenTag ('outputs')
		for outputName in self.outputNames:
			xmlWriter.writeOpenTag (outputName)
			for output in getattr (self, outputName + 'Node') .new:
				xmlWriter.writeField (self.getFileName (output))
			xmlWriter.writeCloseTag ()
		xmlWriter.writeCloseTag ()

		xmlWriter.writeOpenTag ('params')
		for paramName in self.paramNames:
			xmlWriter.writeOpenTag (paramName)
			for param in getattr (self, paramName + 'Node') .new:
				xmlWriter.writeField (param)
			xmlWriter.writeCloseTag ()
		xmlWriter.writeCloseTag ()
		
		xmlWriter.writeCloseTag ()
		return xmlWriter.close ()

	def compute (self, updateLevel, runKey):
		reportDirectory = application.ProjectDirectory + '/reports'
		runId = 'wave' + runKey.replace ('/', '__run')
		argumentFileName = reportDirectory + '/' + runId + '.arguments'
		reportFileName = reportDirectory + '/' + runId + '.report'
		
		self.writeArguments (argumentFileName)

		execute (
			self.getExecutable (),
			runId + ' ' + argumentFileName + ' ' + reportFileName,
			True
		)
		
		if readXmlDict (reportFileName) ['result'] == ['success']:
			deleteFile (reportFileName)
		else:
			raise RunExecutionError (runKey)

class ItemListView (ListView):
	def __init__ (self, itemListNode):
		ListView.__init__ (
			self = self,
			listNode = itemListNode,
			columnLabels = ['item'],
			dropResultGetter = lambda afterItem: dragObject.value,
			dropActionGetter = lambda: DropActions.Copy
		)
		
class ItemView (TextView):
	def __init__ (self, itemListNode):
		self.itemListNode = itemListNode
	
		itemNode = Node ()
		itemNode.dependsOn ([itemListNode], lambda: itemListNode.new [0] .rsplit (':', 2) [0])
		itemNode.validator = lambda value: value == '' or value ==	itemListNode.new [0] .rsplit (':', 2) [0]
		
		itemListNode.dependsOn ([itemNode], lambda: [''])
		itemListNode.validator = lambda value: value == [''] or application.dataMapNode.new.items [value [0]]
		# !!! Use blabla.new i.p.v. value param for validator
	
		TextView.__init__ (
			self = self,
			valueNode = itemNode,
			hint = lambda: (
				'Kind: ' + itemListNode.new [0] .rsplit (':', 2) [1] + '\n' + 
				'Group: ' + itemListNode.new [0] .rsplit (':', 2) [2]
			)
		)
				
	def createWidget (self):
		TextView.createWidget (self)
	
		self.dropLink = Link (self.itemListNode, lambda params: self.itemListNode.change (dragObject.value), None)
		
		self.widget.AllowDrop = True
				
		self.widget.DragEnter += self.dragEnter
		self.widget.DragOver += self.dragOver
		self.widget.DragLeave += self.dragLeave
		self.widget.DragDrop += self.dragDrop
		
		return self.widget
			
	def dragDrop (self, sender, event):
		dragObject.dropAction = DropActions.Copy
		
		if dragObject.dropAction:
			try:
				self.dropLink.read ()								
			except Refusal, refusal:
				handleNotification (refusal) 
				event.Effect = Forms.DragDropEffects.None
		
		if dragObject.imported:
			dragObject.clear ()
						
	def dragEnter (self, sender, event):
		event.Effect = event.AllowedEffect
		
		if dragObject.imported:
			dragObject.value = eval (event.Data.GetData (Forms.DataFormats.Text))
			
		dragObject.targetView = self
		
	def dragOver (self, sender, event):
		dragObject.keyState = event.KeyState	# Don't use directly, use dragObject.modifiers property instead		
		dropAction = DropActions.Copy
	
		if dropAction:						
			event.Effect = 	ifExpr (dropAction == DropActions.Move,	Forms.DragDropEffects.Move,	Forms.DragDropEffects.Copy)
			
		else:
			event.Effect = Forms.DragDropEffects.None				
			
	def dragLeave (self, sender, event):
		if dragObject.imported:
			dragObject.clear ()
			
		dragObject.targetView = None
		
def instantiateProcessor (processorName):
	return application.repertoire.instantiateProcessor (processorName)

def executeScript (script, updateLevel = Run.Full):
	application.dataMap = DataMap ()													# Create empty dataMap
	dataMapGuard = FileGuard (application.ProjectDirectory + '/current.dataMap')		# Create fileGuard on current dataMap
	
	# --- Owning phase
		
	try:																				# Attempt to
		dataMapGuard.request (True)														#	Grab lock
		application.dataMap.load (dataMapGuard.lockedFileName)							#	Load current dataMap
	except:																				# If failed
		application.dataMap.load (application.ProjectDirectory + '/templates.dataMap')	#	Load template dataMap
		application.dataMap.save (dataMapGuard.originalFileName)						#	Save as current dataMap without lock
		dataMapGuard.request (True)														#	Grab lock, template dataMap already loaded
				
	application.owningWaveNr = application.dataMap.newWave ()							# Get a new owningWaveNr, to obtain appropriate dry scripted run
	application.scheduledRunKeyList = []												# Create empty scheduledRunKeyList

	try:																				# Attempt to
		script ()																		#	Dry run script to create runs and own items
	except RunRegistrationError, runRegistrationError:									# If failed
		handleNotification (runRegistrationError)										#	Tell the world
		dataMapGuard.release ()															#	Release lock, don't save dataMap, so revert to old version
		return																			#	Skip remainder of this function executeScript
	
	application.dataMap.save ()															# Save dataMap
	dataMapGuard.release ()																# Release lock for concurrent use
	
	# --- Computation phase
	
	application.updateLevel = updateLevel												# Set updateLevel to full or trial
	application.owningWaveNr = 0														# Set owningWaveNr to 0, to obtain wet scripted run without datamap
	application.completedRunKeyList = []												# Initially no runs are completed
	application.scheduledRunKeyIndex = 0												# Start with run 0
	
	try:																				# Attempt to
		script ()																		#	Wet run script without dataMap to produce data
	except RunExecutionError, runExecutionError:										# If failed
		handleNotification (runExecutionError)											#	Tell the world
	
	# --- Disowning phase
		
	dataMapGuard.request (True)															# Grab lock on dataMap
	application.dataMap.load ()															# Load dataMap, that already has right topology
	
	for runKey in application.scheduledRunKeyList:										# Disown all runs that were scheduled as part of script
		application.dataMap.runs [runKey] .owningWaveNr = 0

	for runKey in application.completedRunKeyList:										# Set updateLevel to full or trial if run successful
		application.dataMap.runs [runKey] .updateLevel = updateLevel
	
	application.dataMap.save ()															# Save dataMap
	dataMapGuard.release ()																# Release lock
