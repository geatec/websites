# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from eden import *
from waveLib.platform import *

class ScriptRecorder:
	Recording, Pausing, Stopped = range (3)
	NameExtension = '.script.py'
	ConnectorName = 'connector.py'
	
	def __init__ (self):
	
		# --- Export nodes
		
		self.stateNode = Node (ScriptRecorder.Stopped)
		
		# --- Local nodes
	
		shortNameNode = application.store.add (Node ('default'))
		fullNamesNode = Node ()
		doBrowseNode = Node (None)
		
		doCloseNode = Node (None)
		
		doRecordNode = Node (None)
		recordEnabledNode = Node ()
		
		doPauseNode = Node (None)
		pauseEnabledNode = Node ()
		
		doStopNode = Node (None)
		stopEnabledNode = Node ()
		
		doPlayNode = Node (Node)
		playEnabledNode = Node ()
		
		# --- Dependencies

		fullNamesNode.dependsOn ([shortNameNode], lambda: [shortNameNode.new + ScriptRecorder.NameExtension])
		shortNameNode.dependsOn ([fullNamesNode], lambda: fullNamesNode.new [0] .rsplit ('.', 2) [0])

		def nextState ():
			if doRecordNode.touched:
				return ScriptRecorder.Recording
			elif doPauseNode.touched:
				return ScriptRecorder.Pausing
			else:
				return ScriptRecorder.Stopped
		
		self.stateNode.dependsOn (
			[doRecordNode, doPauseNode, doStopNode],
			nextState
		)
		
		recordEnabledNode.dependsOn ([self.stateNode], lambda: self.stateNode.new in (ScriptRecorder.Pausing, ScriptRecorder.Stopped))
		pauseEnabledNode.dependsOn ([self.stateNode], lambda: self.stateNode.new == ScriptRecorder.Recording)
		stopEnabledNode.dependsOn ([self.stateNode], lambda: self.stateNode.new in (ScriptRecorder.Recording, ScriptRecorder.Pausing))
		playEnabledNode.dependsOn ([self.stateNode], lambda: self.stateNode.new == ScriptRecorder.Stopped)
			
		# --- Views
		
		self.view = ModelessView (
			GridView ([
				[],
				[
					LLabelView (
						'Script Name'
					),
					HExtensionView (),
					TextView (
						valueNode = shortNameNode,
						editable = False
					),
					HExtensionView (), HExtensionView (), HExtensionView (), HExtensionView (),
					ButtonView (
						actionNode = doBrowseNode,
						icon = 'browse',
						hint = 'Browse'
					)
				],
				[
					FillerView (), FillerView (),
					ButtonView (
						actionNode = doRecordNode,
						icon = 'record',
						enabled = recordEnabledNode,
						hint = lambda: ifExpr (self.stateNode.new == Pausing, 'Continue script recording', 'Start script recording')
					),
					ButtonView (
						actionNode = doPauseNode,
						icon = 'pause',
						enabled = pauseEnabledNode,
						hint = 'Pause script recording'
					),
					ButtonView (
						actionNode = doStopNode,
						icon = 'stop',
						enabled = stopEnabledNode,
						hint = 'Stop script recording'
					),
					FillerView (),
					ButtonView (
						actionNode = doPlayNode,
						icon = 'play',
						enabled = playEnabledNode,
						hint = 'Start script execution'
					),
				],
				[FillerView ()],
				[
					FillerView (), FillerView (), FillerView (), FillerView (), FillerView (), FillerView (),
					ButtonView (
						actionNode = doCloseNode,
						caption = 'Close'
					),
					HExtensionView ()
				]
			]),
			'Script Recorder'
		)
		
		# --- Actions

		doBrowseNode.action = lambda: OpenFileView.show (
			fullNamesNode,
			'Select Script File',
			[('Script Files (*' + ScriptRecorder.NameExtension + ')', [ScriptRecorder.NameExtension])]
		)
		
		def emitPrologueToScript ():
			self.lines = []
			
			self.lines.append ('from connector import *')
			self.lines.append ('')
			
			self.lines.append ('def script ():')
			self.lines.append ('\tpass')
			self.lines.append ('')
				
		doRecordNode.action = emitPrologueToScript
		
		def emitEpilogueToScript ():
			self.lines.append ('')
			self.lines.append ('executeScript (script)')
				
			file = open (fullNamesNode.new [0], 'w')
			file.write ('\n'.join (self.lines))
			file.close ()

			fullConnectorName = fullNamesNode.new [0] .rsplit ('/', 1) [0] + '/' + ScriptRecorder.ConnectorName
			if not fileExists (fullConnectorName):
				connectorLines = []
				connectorLines.append ('import sys')
				connectorLines.append ('')
				connectorLines.append ('sys.path.extend ([')
				connectorLines.append ('\t\'' + application.ApplicationDirectory + '\',')
				connectorLines.append ('\t\'' + application.RepertoireDirectory + '\'')
				connectorLines.append ('])')
				connectorLines.append ('')
				connectorLines.append ('from executor import *')
				connectorLines.append ('')

				connectorFile = open (fullConnectorName, 'w')
				connectorFile.write ('\n'.join (connectorLines))
				connectorFile.close ()
			
		doStopNode.action = emitEpilogueToScript
		
		def playScript ():
			execute (application.PythonInterpreter, fullNamesNode.new [0], False)
		
		doPlayNode.action = playScript
		
		doCloseNode.action = self.view.exit

	def emitLineToScript (self, line):
		self.lines.append ('\t' + line)
