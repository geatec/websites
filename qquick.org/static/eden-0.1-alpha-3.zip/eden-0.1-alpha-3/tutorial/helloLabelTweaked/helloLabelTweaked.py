# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

# helloLabelTweaked.py

from eden import *

text = 'Hello, World'

def tweak (view, color):
	view.widget.BackColor = color

mainView = MainView (
	VGridView ([
		StretchView (),
		CLabelView (
			text,
			tweaker = lambda view: chainCall (
				lambda: tweak (view, Drawing.Color.Red),
				lambda: Font.tweak (view, family = Font.Fixed, size = 20, styles = [Font.Underlined, Font.Italic])
			)
		),
		StretchView ()
	]),
	text,
	tweaker = lambda view: tweak (view, Drawing.Color.Green) 
)

mainView.execute ()
