class Module:
	def __init__ (self, defineParts = False):
		self.modules = []
		if defineParts:
			self.defineParts ()

	def addModule (self, module):
		module.defineModules ()
		self.modules.append (module)
		return module
		
	def defineModules (self):
		pass
		
	def callRecursively (self, definerName):
		if hasattr (self, definerName):
			getattr (self, definerName) ()

		for module in self.modules:
			module.callRecursively (definerName)

	def defineParts (self):
		self.defineModules ()
		self.callRecursively ('defineNodes')
		self.callRecursively ('defineDependencies')
		self.callRecursively ('getView')
		self.callRecursively ('defineActions')
		
	def getView (self):
		if not hasattr (self, 'view'):
			self.view = self.defineViews ()
			
		return self.view
	