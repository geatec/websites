# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from edenLib.base import *
from edenLib.patchedPickle import *

class Store:
	def __init__ (self):
		self.storeDictionary = {}
		self.autoKey = UniqueNumber ()
		
	def name (self, fileName):
		self.fileName = fileName

	def load (self, fileName = None):
		if fileName:
			self.fileName = fileName
	
		try:
			file = open (self.fileName, 'r')
#			storeList = eval (file.read ())
#			storeList = load (file)
			aString = file.read ()
			storeList = loads (aString)
			file.close ()
			self.loaded = True
		except:
			storeList = []
			self.loaded = False
			
		for item in storeList:
			try:
				self.storeDictionary [item [0]] .state = item [1]
			except Exception, exception:
				problem = (
					'Can not restore item ' + str (item [0]) +
					' with value ' + str (item [1]) +
					' from file ' + self.fileName + ', '
				)

				handleNotification (Remark (problem + exMessage (exception), report = problem + exReport (exception)))
				
	def save (self, fileName = None):
		if fileName:
			self.fileName = fileName
	
		storeList = []
		for key in self.storeDictionary:
			try:
				storeList.append ((key, self.storeDictionary [key] .state))
			except:	# The object belonging to key may not yet have a valid state
				pass
			
		file = open (self.fileName, 'w')
#		file.write (str (storeList))
#		dump (storeList, file)
		aString = dumps (storeList)
		file.write (aString)
		file.close ()

	def add (self, item, key = None):
		if key == None:
			key = self.autoKey.getNext ()
		
		self.storeDictionary [key] = item
		return item
	
	def remove (self, item, key):
		del self.storeDictionary [key]
