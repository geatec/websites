# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from edenLib.node import *
from edenLib.store import *
from edenLib.view import *

# import sys

# sys.LoadAssemblyByName("System.Drawing")
# sys.LoadAssemblyByName("System.Windows.Forms")

import clr

clr.AddReference ('System.Drawing')
clr.AddReference ('System.Windows.Forms')

from System import Drawing
from System.Windows import Forms

class OpenFileView:
	@classmethod
	def show (cls, fileNameListNode, caption, filterOptions, multiSelect = False, tweaker = None):
		widget = Forms.OpenFileDialog ()
		widget.Multiselect = multiSelect
		widget.CheckFileExists = False
		widget.SupportMultiDottedExtensions = True
		widget.Title = caption
		widget.Filter = '|'.join ([filterOption [0] + '|*' +  ';*'.join (filterOption [1]) for filterOption in filterOptions])
		if len (fileNameListNode.new):
			widget.FileName = fileNameListNode.new [0] .replace ('/', '\\')
		else:
			widget.FileName = ''

		if tweaker:
			tweaker (widget)	

		if widget.ShowDialog () == Forms.DialogResult.OK:
			fileNameListNode.change ([fileName.replace ('\\', '/') for fileName in widget.FileNames], True)
			
class ButtonId:
	Abort, Cancel, Ignore, No, Null, Ok, Retry, Yes = range (8)

class MessageView:
	Results = {
		Forms.DialogResult.Abort : ButtonId.Abort,
		Forms.DialogResult.Cancel : ButtonId.Cancel,
		Forms.DialogResult.Ignore : ButtonId.Ignore,
		Forms.DialogResult.No : ButtonId.No,
		Forms.DialogResult.None : ButtonId.Null,
		Forms.DialogResult.OK : ButtonId.Ok,
		Forms.DialogResult.Retry : ButtonId.Retry,
		Forms.DialogResult.Yes : ButtonId.Yes
	}
	
	FormsButtonCombinations = {
		frozenset ([ButtonId.Abort, ButtonId.Retry, ButtonId.Ignore]) : Forms.MessageBoxButtons.AbortRetryIgnore,
		frozenset ([ButtonId.Ok]) : Forms.MessageBoxButtons.OK,
		frozenset ([ButtonId.Ok, ButtonId.Cancel]) : Forms.MessageBoxButtons.OKCancel,
		frozenset ([ButtonId.Retry, ButtonId.Cancel]) : Forms.MessageBoxButtons.RetryCancel,
		frozenset ([ButtonId.Yes, ButtonId.No]) : Forms.MessageBoxButtons.YesNo,
		frozenset ([ButtonId.Yes, ButtonId.No, ButtonId.Cancel]) : Forms.MessageBoxButtons.YesNoCancel
	}
		
	FormsIcons = {
		'asterisk' : Forms.MessageBoxIcon.Asterisk,
		'error' : Forms.MessageBoxIcon.Error,
		'exclamation' : Forms.MessageBoxIcon.Exclamation,
		'hand' : Forms.MessageBoxIcon.Hand,
		'information' : Forms.MessageBoxIcon.Information,
		'none' : Forms.MessageBoxIcon.None,
		'question' : Forms.MessageBoxIcon.Question,
		'stop' : Forms.MessageBoxIcon.Stop,
		'warning' : Forms.MessageBoxIcon.Warning
	}
	
	@classmethod
	def show (cls, buttonIds, message, caption, icon = 'none'):
		try:
			formsButtonCombination = cls.FormsButtonCombinations [frozenset (buttonIds)]
		except:
			print 'Internal error: Invalid combination of buttons ' + str (buttonIds) + ' in call to showMessageView'
			
		try:
			formsIcon = cls.FormsIcons [icon]
		except:
			print 'Internal error: Invalid icon \'' + icon + '\' in call to showMessageView'
							
		return cls.Results [Forms.MessageBox.Show (message, caption, formsButtonCombination, formsIcon)]
		
class NotificationView (MessageView):
	@classmethod
	def show (cls, notification):
		return MessageView.show ([ButtonId.Ok], notification.message, notification.caption, notification.icon)

app.notificationShower = NotificationView.show
