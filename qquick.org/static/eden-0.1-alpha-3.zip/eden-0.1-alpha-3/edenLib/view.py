# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

from edenLib.node import *
from edenLib.store import *

import clr

clr.AddReference ('System.Drawing')
clr.AddReference ('System.Windows.Forms')

from System import Drawing
from System.Windows import Forms
from System.Windows.Forms import Keys	# In a non .NET implementation the same identifiers should be defined as members of a Keys class

mainViewStore = Store ()
currentViewStore = CallableValue (mainViewStore)	# All applicable views will add themselves to currentViewStore ()

application.designMode = False

class Clipboard:
	def read (self):
		return eval (Forms.Clipboard.GetText ())
	
	def write (self, data):
		Forms.Clipboard.SetText (str (data))
		
clipboard = Clipboard ()

class DropActions:
	Null = 0
	Move = 1
	Copy = 2
	Link = 3

class DragObject:
	def __init__ (self):
		self.clear ()
	
	def clear (self):
		self.value = None		
		self.sourceView = None
		self.targetView = None
		self.dropAction = None
		
	reflexive = property (lambda self: self.sourceView is self.targetView)
	imported = property (lambda self: self.sourceView is None)		
	exported = property (lambda self: self.targetView is None)
	modifiers = property (lambda self: ifExpr (self.keyState & 8, [Keys.Control], [])) 
			
dragObject = DragObject ()
		
def assignText (target, source):	# ??? Passing target.Text out as param fails. Why?
	target.Text = source

def assignImage (target, source):	# ??? Passing target.Image out as param fails. Why?
	target.Image = source

def assignTitle (target, source):
	target.Title = source
	
def getImage (stringOrImage):
	if stringOrImage.__class__ == str:
		for bitMapDirectory in application.BitMapDirectories:
			try:
				image = Drawing.Image.FromFile (bitMapDirectory + '/' + stringOrImage + '.bmp')
				break
			except IOError:
				pass
	else:
		image = stringOrImage
	
	try:
		image.MakeTransparent ()
	except:
		pass
		
	return image

def getHint (hintGetter):
	try:
		return str (hintGetter ())
	except:
		return '???'

def tweak (view):
	if view.tweaker:
		view.tweaker (view)

class EnabledViewMix:
	def __init__ (self, enabled):
		self.enabledNode = getNode (enabled)
	
	def bareWriteEnabled (self):
		self.widget.Enabled = self.enabledNode.new
		
	def attachEnabledToWidget (self):
		if self.enabledNode:
			self.enabledLink = Link (self.enabledNode, None, self.bareWriteEnabled)
			self.enabledLink.write ()
			
class EditableViewMix:
	def __init__ (self, editable):
		self.editableNode = getNode (editable)
		
	def bareWriteEditable (self):
		self.widget.ReadOnly = not self.editableNode.new
		
	def attachEditableToWidget (self):
		if self.editableNode:
			self.editableLink = Link (self.editableNode, None, self.bareWriteEditable)
			self.editableLink.write ()
			
class HintedViewMix:
	def __init__ (self, hint):
		self.hintGetter = getFunction (hint)
		
	def attachHintedToWidget (self):
		if self.hintGetter:
			self.toolTip = Forms.ToolTip ()
			self.toolTip.ShowAlways = True
			self.widget.MouseEnter += self.updateHint

	def updateHint (self, sender, event):
		self.toolTip.Active = False
		self.toolTip.SetToolTip (self.widget, getHint (self.hintGetter))
		self.toolTip.Active = True
			
class MultiSelectViewMix:
	def __init__ (self, multiSelect):
		self.multiSelectNode = getNode (multiSelect)
		
	def bareWriteMultiSelect (self):
		self.widget.MultiSelect = not self.multiSelectNode.new
		
	def attachMultiSelectToWidget (self):
		if self.multiSelectNode:
			self.multiSelectLink = Link (self.multiSelectNode, None, self.bareWriteMultiSelect)
			self.multiSelectLink.write ()
			
class KeysViewMix:
	def __init__ (self, keysDownNode, keysUpNode, keyCharNode, keysHandled):
		self.keysDownNode = keysDownNode
		self.keysUpNode = keysUpNode
		self.keyCharNode = keyCharNode
		self.keysHandled = getFunction (keysHandled)
	
	def getEventKeys (self, event):
		return set ([event.KeyCode] + [modifier for modifier in [Keys.Alt, Keys.Control, Keys.Shift] if modifier & event.Modifiers])
	
	def bareReadKeysDown (self, params):
		self.keysDownNode.change (self.getEventKeys (params [1]), True)

	def bareReadKeysUp (self, params):
		self.keysUpNode.change (self.getEventKeys (params [1]), True)
		
	def bareReadKeyChar (self, params):
		self.keyCharNode.change (params [1] .KeyChar, True)

	def onKeyPress (self, sender, event):
		if self.keyCharNode:
			self.keyCharLink.read (sender, event)
			
		if not self.keysHandled is None:
			event.Handled = self.keysHandled ()
		
	def attachKeysToWidget (self):
		if self.keysDownNode:
			self.keysDownLink = Link (self.keysDownNode, self.bareReadKeysDown, None)
			self.widget.KeyDown += self.keysDownLink.read

		if self.keysUpNode:
			self.keysUpLink = Link (self.keysUpNode, self.bareReadKeysUp, None)
			self.widget.KeyUp += self.keysUpLink.read

		if self.keyCharNode:
			self.keyCharLink = Link (self.keyCharNode, self.bareReadKeyChar, None)
			
		if self.keyCharNode or self.keysHandled:
			self.widget.KeyPress += self.onKeyPress

class FocusViewMix:
	def __init__ (self):
		self.containsFocus = False
		
	focused = property (lambda self: self.widget.Focused)
		
	def attachFocusToWidget (self):
	
		def enter (sender, event):
			self.containsFocus = True
	
		self.widget.Enter += enter
		
		def leave (sender, event):
			self.containsFocus = False
			
		self.widget.Leave += leave
		
	def focus (self):
		self.widget.Focus ()

class LabelViewBase (HintedViewMix):
	def __init__ (self, caption, hint, tweaker):
		HintedViewMix.__init__ (self, hint)
		self.captionNode = getNode (caption)
		self.tweaker = tweaker
		self.stretchHeight = False
	
	def createWidget (self):
		self.widget = Forms.Label ()
		self.attachHintedToWidget ()
		self.widget.AutoSize = True
		self.widget.Dock = Forms.DockStyle.Top
		self.widget.TextAlign = Drawing.ContentAlignment.MiddleLeft
		
		self.link = Link (self.captionNode, None, lambda: assignText (self.widget, str (self.captionNode.new)))
		
		self.link.write ()
		return self.widget

class LLabelView (LabelViewBase):
	def __init__ (self, caption, hint = None, tweaker = None):
		LabelViewBase.__init__ (self, caption, hint, tweaker)

	def createWidget (self):
		LabelViewBase.createWidget (self)
		tweak (self)
		return self.widget

class RLabelView (LabelViewBase):
	def __init__ (self, caption, hint = None, tweaker = None):
		LabelViewBase.__init__ (self, caption, hint, tweaker)
		
	def createWidget (self):
		LabelViewBase.createWidget (self)
		self.widget.TextAlign = Drawing.ContentAlignment.MiddleRight
		tweak (self)
		return self.widget
		
class CLabelView (LabelViewBase):
	def __init__ (self, caption, hint = None, tweaker = None):
		LabelViewBase.__init__ (self, caption, hint, tweaker)
		
	def createWidget (self):
		LabelViewBase.createWidget (self)
		self.widget.TextAlign = Drawing.ContentAlignment.MiddleCenter
		tweak (self)
		return self.widget
		
class FillerView (CLabelView):
	def __init__ (self):
		if application.designMode:
			caption = '[FILLER VIEW]'
		else:
			caption = ''
			
		CLabelView.__init__ (self, caption)

class StretchView:
	def __init__ (self):
		self.stretchHeight = True
				
	def createWidget (self):
		self.widget = Forms.Panel ()
		self.widget.Dock = Forms.DockStyle.Fill
		return self.widget		
		
class ButtonViewBase (EnabledViewMix):
	def __init__ (self, actionNode, caption, icon, enabled, tweaker):
		EnabledViewMix.__init__ (self, enabled)
		self.actionNode = actionNode
		self.captionNode = getNode (caption)
		self.iconNode = getNode (icon)
		self.tweaker = tweaker
		self.stretchHeight = False

	def createWidget (self):
		self.bareCreateWidget ()
		self.attachEnabledToWidget ()
		
		self.actionLink = Link (self.actionNode, lambda params: self.actionNode.change (None, True), None)
		self.widget.Click += self.actionLink.read				
		
		if self.captionNode:
			self.captionLink = Link (self.captionNode, None, lambda: assignText (self.widget, str (self.captionNode.new)))
			self.captionLink.write ()
		
		if self.iconNode:
			self.iconLink = Link (self.iconNode, None, lambda: assignImage (self.widget, getImage (self.iconNode.new)))
			self.iconLink.write ()	 
		
		tweak (self)
		return self.widget
			
class ButtonView (ButtonViewBase, HintedViewMix):
	def __init__ (self, actionNode, caption = None, icon = None, enabled = None, hint = None, tweaker = None):
		ButtonViewBase.__init__ (self, actionNode, caption, icon, enabled, tweaker)
		HintedViewMix.__init__ (self, hint)
		
	def bareCreateWidget (self):
		self.widget = Forms.Button ()
		self.attachHintedToWidget ()	
		self.widget.Dock = Forms.DockStyle.Top
		
class MenuButtonView (ButtonViewBase):
	def __init__ (self, actionNode, caption = None, icon = None, enabled = None, tweaker = None):
		ButtonViewBase.__init__ (self, actionNode, caption, icon, enabled, tweaker)
				
	def bareCreateWidget (self):
		self.widget = Forms.ToolStripButton ()
		self.widget.Width = 120
		
class TextView (EnabledViewMix, EditableViewMix, HintedViewMix, FocusViewMix):
	def __init__ (self, valueNode, enabled = None, editable = None, hint = None, tweaker = None):
		EnabledViewMix.__init__ (self, enabled)
		EditableViewMix.__init__ (self, editable)
		HintedViewMix.__init__ (self, hint)
		FocusViewMix.__init__ (self)	
		self.valueNode = valueNode
		self.tweaker = tweaker
		self.stretchHeight = False
	
	def createWidget (self):
		self.widget = Forms.TextBox ()
		self.attachEnabledToWidget ()
		self.attachEditableToWidget ()
		self.attachHintedToWidget ()	
		self.attachFocusToWidget ()	
		self.widget.Dock = Forms.DockStyle.Top
		
		self.link = Link (self.valueNode, lambda params: self.valueNode.change (str (self.widget.Text)), lambda: assignText (self.widget, str (self.valueNode.new)))											
		
		self.widget.LostFocus += self.link.read	# The leave event is not generated if next focus is on ListView
		self.widget.KeyDown += lambda sender, event: event.KeyCode != Forms.Keys.Enter or self.link.read (sender, event)	# .NET lib doc: KeyPressed only generated for char keys
			
		self.link.write ()
		tweak (self)
		return self.widget
		
class DeltaView (EnabledViewMix, EditableViewMix, HintedViewMix, FocusViewMix):
	def __init__ (self, valueNode, enabled = None, editable = None, hint = None, tweaker = None):
		EnabledViewMix.__init__ (self, enabled)
		EditableViewMix.__init__ (self, editable)
		HintedViewMix.__init__ (self, hint)	
		FocusViewMix.__init__ (self)	
		self.valueNode = valueNode
		self.tweaker = tweaker
		self.stretchHeight = False
	
	def createWidget (self):
		self.widget = Forms.NumericUpDown ()
		self.attachEnabledToWidget ()
		self.attachEditableToWidget ()
		self.attachHintedToWidget ()	
		self.attachFocusToWidget ()	
		self.widget.Dock = Forms.DockStyle.Top
		self.link = Link (self.valueNode, lambda params: self.valueNode.change (str (self.widget.Value)), lambda: assignText (self.widget, str (self.valueNode.new)))	# Read Value since Text changes too late, write Text since whe have an assignText anyhow.
		
		self.widget.ValueChanged += self.link.read
												
		self.link.write ()
		tweak (self)
		return self.widget	

class ComboView (EnabledViewMix, EditableViewMix, HintedViewMix, FocusViewMix):
	def __init__ (self, valueNode, options, enabled = None, editable = None, hint = None, tweaker = None):
		EnabledViewMix.__init__ (self, enabled)
		EditableViewMix.__init__ (self, editable)
		HintedViewMix.__init__ (self, hint)	
		FocusViewMix.__init__ (self)	
		self.valueNode = valueNode
		self.optionsNode = getNode (options)
		self.tweaker = tweaker
		self.stretchHeight = False
		
	def createWidget (self):
		self.widget = Forms.ComboBox ()
		self.attachEnabledToWidget ()
		self.attachEditableToWidget ()
		self.attachHintedToWidget ()
		self.attachFocusToWidget ()	
		self.widget.Dock = Forms.DockStyle.Top
		
		self.valueLink = Link (self.valueNode, lambda params: self.valueNode.change (str (self.widget.Text)), lambda: assignText (self.widget, str (self.valueNode.new)))
		
		self.optionsLink = Link (self.optionsNode, None, self.bareWriteOptions)
		
		self.widget.LostFocus += self.valueLink.read	# The leave event is not generated if next focus is on ListView
		self.widget.KeyDown += lambda sender, event: event.KeyCode != Forms.Keys.Enter or self.link.read (sender, event)	# .NET lib doc: KeyPressed only generated for char keys
		self.widget.SelectedValueChanged += self.valueLink.read				
												
		self.valueLink.write ()
		self.optionsLink.write ()
		tweak (self)
		return self.widget
		
	def bareWriteOptions (self):
		self.widget.Items.Clear ()
		
		for option in self.optionsNode.new:
			self.widget.Items.Add (str (option))
		
class CheckView (EnabledViewMix, EditableViewMix, HintedViewMix, FocusViewMix):
	def __init__ (self, valueNode, caption, enabled = None, editable = None, hint = None, tweaker = None):
		EnabledViewMix.__init__ (self, enabled)
		EditableViewMix.__init__ (self, editable)
		HintedViewMix.__init__ (self, hint)	
		FocusViewMix.__init__ (self)	
		self.valueNode = valueNode
		self.captionNode = getNode (caption)
		self.tweaker = tweaker
		self.stretchHeight = False
			
	def createWidget (self):
		self.widget = Forms.CheckBox ()
		self.attachEnabledToWidget ()
		self.attachEditableToWidget ()
		self.attachHintedToWidget ()
		self.attachFocusToWidget ()	
		self.widget.Dock = Forms.DockStyle.Top
		
		self.valueLink = Link (self.valueNode, lambda params: self.valueNode.change (self.widget.Checked), self.bareWrite)
		self.widget.CheckedChanged += self.valueLink.read		
		self.valueLink.write ()				
		
		self.captionLink = Link (self.captionNode, None, lambda: assignText (self.widget, str (self.captionNode.new)))
		self.captionLink.write ()
				 	
		tweak (self)
		return self.widget
			
	def bareWrite (self):
		self.widget.Checked = self.valueNode.new
		
class RadioButtonView (EnabledViewMix, EditableViewMix, HintedViewMix, FocusViewMix):
	def __init__ (self, valueNode, caption, marker = None, enabled = None, editable = None, hint = None, tweaker = None):
		EnabledViewMix.__init__ (self, enabled)
		EditableViewMix.__init__ (self, editable)
		HintedViewMix.__init__ (self, hint)	
		FocusViewMix.__init__ (self)	
		self.valueNode = valueNode
		self.captionNode = getNode (caption)
		
		if not marker is None:
			self.marker = marker
		else:
			self.marker = caption
		
		self.tweaker = tweaker		
		self.stretchHeight = False
		
	def createWidget (self):
		self.widget = Forms.RadioButton ()
		self.attachEnabledToWidget ()
		self.attachEditableToWidget ()
		self.attachHintedToWidget ()
		self.attachFocusToWidget ()	
		self.widget.Dock = Forms.DockStyle.Top
		
		self.widget.AutoCheck = False
		
		self.valueLink = Link (self.valueNode, lambda params: self.valueNode.change (self.marker), self.bareWrite)
		self.widget.Click += self.valueLink.read		
		self.valueLink.write ()				
		
		self.captionLink = Link (self.captionNode, None, lambda: assignText (self.widget, str (self.captionNode.new)))
		self.captionLink.write ()			 
		
		tweak (self)
		return self.widget
			
	def bareWrite (self):
		self.widget.Checked = self.valueNode.new == self.marker
					
# <list> = [<item>, ...]
# <item> = <field> | [<field>, ...]

class ListView (EnabledViewMix, MultiSelectViewMix, FocusViewMix):

	# --- Constructor and widget creation method, like supported by all views

	def __init__ (
		self,
		listNode,
		columnLabels,
		selectedListNode = None,
		enabled = None,
		contextMenuView = None,
		checkedListNode = None,
		transformer = None,
		dragObjectGetter = None,
		dragResultGetter = None,
		dropResultGetter = None,
		dropActionGetter = None,
		hoverListNode = None,
		hintGetter = None,
		key = None,
		sortColumnNumberNode = None,
		clickedColumnIndexNode = None,
		multiSelect = None,		
		tweaker = None
	):
		EnabledViewMix.__init__ (self, enabled)
		MultiSelectViewMix.__init__ (self, multiSelect)
		FocusViewMix.__init__ (self)	
		
		self.listNode = listNode
		self.columnLabelsNode = getNode (columnLabels)
		self.selectedListNode = selectedListNode
		self.contextMenuView = contextMenuView
		self.checkedListNode = checkedListNode
		self.transformer = transformer
		self.dragObjectGetter = dragObjectGetter
		self.dragResultGetter = dragResultGetter
		self.dropResultGetter = dropResultGetter
		self.dropActionGetter = dropActionGetter
		self.hoverListNode = hoverListNode
		self.hintGetter = hintGetter
		self.sortColumnNumberNode = sortColumnNumberNode
		self.clickedColumnIndexNode = clickedColumnIndexNode
		self.tweaker = tweaker
		
		self.stretchHeight = True
		self.sortColumnNumber = 1
		
		currentViewStore () .add (self, key)
	
	def createWidget (self):
		self.widget = Forms.ListView ()
		self.attachEnabledToWidget ()
		self.attachMultiSelectToWidget ()
		self.attachFocusToWidget ()	
		self.widget.Dock = Forms.DockStyle.Fill
		
		def setState (sender, event):
			self.state = []
			for columnHeader in self.widget.Columns:
				self.state.append (columnHeader.Width)

		def getStateAndAllowSetState (sender, event):
			if self.widget.Visible:
				if hasattr (self, 'state'):	# Either from viewStore or from previously closed modal dialog widget
					try:
						for columnIndex, columnHeader in enumerate (self.widget.Columns)	:
							columnHeader.Width = self.state [columnIndex]
					except:	# If impossible to obey, due to e.g. minimum size
						pass
					
				self.widget.ColumnWidthChanged += setState
		
		self.widget.VisibleChanged += getStateAndAllowSetState
			
		if self.checkedListNode:
			self.widget.CheckBoxes = True
			
		self.widget.View = Forms.View.Details
		self.widget.FullRowSelect = True
		self.widget.HideSelection = False
		self.widget.AllowColumnReorder = True
		self.widget.AutoArrange = True
		self.widget.AllowDrop = True
		self.widget.GridLines = True
		
		if self.clickedColumnIndexNode:
			self.clickedColumnIndexLink = Link (self.clickedColumnIndexNode, self.bareReadClickedColumnIndex, None)
			self.widget.MouseClick += self.clickedColumnIndexLink.read
		
		if self.sortColumnNumberNode:
			self.listLink = Link (self.listNode, None, lambda: self.bareWrite (self.listNode, self.widget.Items))
			self.sortColumnNumberLink = Link (self.sortColumnNumberNode, self.bareReadSortColumnNumber, None)
			self.widget.ColumnClick += self.sortColumnNumberLink.read
		else:
			self.listLink = Link (self.listNode, self.bareReadSorted, lambda: self.bareWrite (self.listNode, self.widget.Items))
			self.widget.ColumnClick += self.listLink.read
			
		self.listLink.write ()
		
		self.columnLabelsLink = Link (self.columnLabelsNode, None, lambda: self.bareWriteColumnLabels ())
		self.columnLabelsLink.write ()
		
		if self.selectedListNode:
			if not hasattr (self.selectedListNode, 'getter'):
				self.selectedListNode.dependsOn ([self.listNode], self.interestingItemList)
				
			self.selectedListLink = Link (self.selectedListNode, lambda params: self.listLink.writing or self.bareReadListViewItems (self.selectedListNode, self.widget.SelectedItems), self.bareWriteSelectedItems)
			self.selectedListLink.writeBack = False
			self.widget.MouseUp += self.selectedListLink.read
			self.widget.KeyUp += self.selectedListLink.read
						
		if self.checkedListNode:
			self.checkedListNode.dependsOn ([self.listNode], self.checkedItemsLeft)  
			self.checkedListLink = Link (self.checkedListNode, lambda params: self.listLink.writing or self.bareReadListViewItems (self.checkedListNode, self.widget.CheckedItems), self.bareWriteCheckedItems)
			self.checkedListLink.writeBack = False
			
			self.preparedToCheckItems = False
			
			def early (*params):
				self.preparedToCheckItems = True
			
			self.widget.ItemCheck += early
			
			def late (*params):
				if self.preparedToCheckItems:
					self.checkedListLink.read ()

				self.preparedToCheckItems = False
			
			self.widget.ItemChecked += late
		
		if self.contextMenuView:
			self.widget.ContextMenuStrip = self.contextMenuView.createWidget ()
			self.widget.MouseUp += lambda sender, event: event.Button != Forms.MouseButtons.Right or sender.ContextMenuStrip.Show (sender, event.Location)
			
		if self.dragObjectGetter:
			self.widget.ItemDrag += self.itemDrag
			
		if self.dragResultGetter:
			self.dragLink = Link (self.listNode, lambda params: self.listNode.change (self.dragResultGetter ()), None)
			
		if self.dropActionGetter:
			self.dropLink = Link (self.listNode, lambda params: self.listNode.change (self.dropResultGetter (params [0])), None)
			
			self.widget.DragEnter += self.dragEnter
			self.widget.DragOver += self.dragOver
			self.widget.DragLeave += self.dragLeave
			self.widget.DragDrop += self.dragDrop
			
		self.toolTip = Forms.ToolTip ()
		self.toolTip.ShowAlways = True
		self.hoverListViewItem = None
		self.widget.MouseMove += self.track
		
		tweak (self)
		return self.widget

	# --- Low level read methods to be passed to Links

	def newSortColumnNumber (self, sortColumnIndex):
		if sortColumnIndex == abs (self.sortColumnNumber) - 1:	# If denotes same column
			self.sortColumnNumber = -self.sortColumnNumber
		else:
			self.sortColumnNumber = sortColumnIndex + 1
			
		return self.sortColumnNumber
		
	def bareReadSorted (self, params):
		listToSort = self.listNode.new	# We're still before the change event, so don't use self.listNode.old	
		self.listNode.change (sortList (listToSort, self.newSortColumnNumber (params [1] .Column), self.transformer))
		
	def bareReadSortColumnNumber (self, params):
		self.sortColumnNumberNode.change (self.newSortColumnNumber (params [1] .Column))
	
	def bareReadClickedColumnIndex (self, params):
		topListViewItem = self.widget.TopItem

		if topListViewItem == None:
			self.clickedColumnIndexNode.change (-1)
			return

		moreThanOneColumn = topListViewItem.SubItems
			
		boundsList = []	
			
		for subItem in topListViewItem.SubItems:
			boundsList.append ((subItem.Bounds.Left, subItem.Bounds.Right))
			
		if len (boundsList) > 1:
			boundsList [0] = (boundsList [0][0], boundsList [1][0])	# Correct first subItem, because in .NET the first subItem is the whole item.
				
		for index, bounds in enumerate (boundsList):
			if bounds [0] < params [1] .X < bounds [1]:
				self.clickedColumnIndexNode.change (index)
				break
		else:
			return self.clickedColumnIndexNode.change (-1)

	def bareReadListViewItems (self, node, listViewItems):
		aList = []			
		for listViewItem in listViewItems:
			aList.append (self.itemFromListViewItem (listViewItem))
			
		node.change (aList)
		
	# --- Low level write methods to be passed to Links	
		
	def bareWrite (self, node, listViewItems):
		if node == self.listNode:
			self.widget.SuspendLayout ()
			
		listViewItems.Clear ()			

		if len (node.new):				
			if self.transformer:
				listViewItemsBuffer = []
				
				for item in node.new:					
					listViewItem = Forms.ListViewItem ([str (field) for field in self.transformer (item)])		
					listViewItem.Tag = item
					listViewItemsBuffer.append (listViewItem)
					
			elif node.new [0] .__class__ == list:
				listViewItemsBuffer = [Forms.ListViewItem ([str (field) for field in item]) for item in node.new]					
			else:
				listViewItemsBuffer = [Forms.ListViewItem (str (item)) for item in node.new]
			
			listViewItems.AddRange (listViewItemsBuffer)
			
		if node == self.listNode:
			self.widget.ResumeLayout ()

	def bareWriteColumnLabels (self):
		self.widget.Columns.Clear ()
		
		for columnLabel in self.columnLabelsNode.new:
			columnHeader = Forms.ColumnHeader ()
			columnHeader.Text = str (columnLabel)	# columnLabelsNode.new may be composed of raw contents of other nodes, not only strings
			self.widget.Columns.Add (columnHeader)
				
	def bareWriteSelectedItems (self):
		self.listNode.evaluate ()				# Make sure widget has newest version, so selection will succeed
	
		for listViewItem in self.widget.SelectedItems:
			listViewItem.Selected = False
	
		for listViewItem in self.widget.Items:
			candidateItem = self.itemFromListViewItem (listViewItem)
			
			for selectedItem in self.selectedListNode.new:
				if candidateItem == selectedItem:
					listViewItem.Selected = True
					lastSelectedListViewItem = listViewItem
					break
					
		try:
			lastSelectedListViewItem.EnsureVisible ()
		except:
			pass		
						
	def bareWriteCheckedItems (self):
		for listViewItem in self.widget.CheckedItems:
			listViewItem.Checked = False
	
		for listViewItem in self.widget.Items:
			candidateItem = self.itemFromListViewItem (listViewItem)

			for checkedItem in self.checkedListNode.new:
				if candidateItem == checkedItem:
					listViewItem.Checked = True
					break
					
	# --- Drag and drop support methods
	
	def setTargetListViewItem (self, event):
		# From the combination (self.targetListViewItem, self.targetValid) the insertion location can be deduced:
		# - (<anItem>, True) means: insert below underlined item
		# - (None, True) means: insert above first item
		# - (None, False) means: invalid insertion location
		
		try:
			topListViewItem = self.widget.TopItem
		
			mousePoint = self.widget.PointToClient (Drawing.Point (event.X, event.Y))							# Normalized mouse cursor
			targetPoint = Drawing.Point (mousePoint.X, mousePoint.Y - 2 * topListViewItem.Bounds.Height / 3)	# Item above rather than under mouse cursor
																												# Target item is underlined item, line is approximately on mouse cursor
			
			if targetPoint.Y > self.widget.TopItem.Bounds.Top:													# Regular or invalid item
				self.targetListViewItem = self.widget.GetItemAt (targetPoint.X, targetPoint.Y)
				self.targetValid = not self.targetListViewItem is None
			else:																								# If target point above top item
				self.targetListViewItem = None																	# Fictional sentry item above first item
				self.targetValid = self.widget.TopItem == self.widget.Items [0]									# Sentry underlined if line is above first item
		except AttributeError:	# topListViewItem is None, None doesn't have Bounds attribute
			self.targetListViewItem = None
			self.targetValid = len (self.widget.Items) == 0														# Empty list, see target as valid, append to list
		
	def drawTargetLine (self, appear):
		try:
			color = ifExpr (appear, Drawing.Color.Blue, Drawing.Color.White)
				
			if self.targetValid:
				if self.targetListViewItem:
					referenceListViewItem = self.targetListViewItem
					y = referenceListViewItem.Bounds.Bottom						
				else:
					referenceListViewItem = self.widget.TopItem
					y = referenceListViewItem.Bounds.Top
				
				self.widget.CreateGraphics () .DrawLine (Drawing.Pen (color, 1), referenceListViewItem.Bounds.Left, y, referenceListViewItem.Bounds.Right, y)
		except:
			pass				
			
	def itemDrag (self, sender, event):
		dragObject.sourceView = self
		dragObject.value = self.dragObjectGetter ()
	
		if self.widget.DoDragDrop (str (dragObject.value), Forms.DragDropEffects.Move | Forms.DragDropEffects.Copy) != Forms.DragDropEffects.None:
			if self.dragResultGetter:
				self.dragLink.read ()
		
		dragObject.clear ()
	
	def dragDrop (self, sender, event):
		self.drawTargetLine (False)
		
		dragObject.keyState = event.KeyState	# Don't use directly, use dragObject.modifiers property instead		
		dragObject.dropAction = self.dropActionGetter ()
		
		if dragObject.dropAction and self.targetValid:
			try:		
				if self.targetListViewItem:
					self.dropLink.read ([self.itemFromListViewItem (self.targetListViewItem)])								
				else:
					self.dropLink.read ([])
			except Refusal, refusal:
				handleNotification (refusal) 
				event.Effect = Forms.DragDropEffects.None
		
		if dragObject.imported:
			dragObject.clear ()
						
	def dragEnter (self, sender, event):
		event.Effect = event.AllowedEffect
		
		self.targetListViewItem = None	
		self.targetValid = False
			
		if dragObject.imported:
			dragObject.value = eval (event.Data.GetData (Forms.DataFormats.Text))
			
		dragObject.targetView = self
		
	def dragOver (self, sender, event):
		self.drawTargetLine (False)
		
		dragObject.keyState = event.KeyState	# Don't use directly, use dragObject.modifiers property instead		
		dropAction = self.dropActionGetter ()
	
		if dropAction:						
			self.setTargetListViewItem (event)
			
			event.Effect = ifExpr (self.targetValid,
				ifExpr (dropAction == DropActions.Move,
					Forms.DragDropEffects.Move,
					Forms.DragDropEffects.Copy),
				Forms.DragDropEffects.None)
			
			self.drawTargetLine (True)
							
		else:
			event.Effect = Forms.DragDropEffects.None				
			
	def dragLeave (self, sender, event):
		self.drawTargetLine (False)
		
		if dragObject.imported:
			dragObject.clear ()
			
		dragObject.targetView = None

	# --- Miscellaneous methods
	
	def track (self, sender, event):
		hoverListViewItem = self.widget.GetItemAt (event.X, event.Y)
		if not hoverListViewItem is self.hoverListViewItem:
			self.hoverListViewItem = hoverListViewItem
			
			if self.hoverListNode:
				if self.hoverListViewItem:
					self.hoverListNode.change ([self.itemFromListViewItem (self.hoverListViewItem)])
				else:
					self.hoverListNode.change ([])
				
			self.toolTip.Active = False
			
			if self.hintGetter and self.hoverListViewItem:
				self.toolTip.SetToolTip (self.widget, getHint (self.hintGetter))
				self.toolTip.Active = True
	
	def interestingItemList (self):							# Order n rather than n**2
		indexNew = len (self.listNode.new) - 1
		growth = indexNew - (len (self.listNode.old) - 1)
		
		if growth == 0:										# If same size
			if self.listNode.new == self.listNode.old:			# Lists are identical
				return self.selectedListNode.old
			else:												# Both insertion and removal have taken place
				return []

		# Look for a difference between the lists
		try:
			while self.listNode.new [indexNew] == self.listNode.old [indexNew - growth]:
				indexNew -= 1				
		except IndexError:
			pass	
		# When here, a difference has been found, including exhaustion of exactly one of both lists
	
		if indexNew == -1:									# If index points at fictional sentry at index -1
			return []										#	Don't return sentry, since it is fictional...
		else:												# If index points at a real item
			return [self.listNode.new [indexNew]]			#	Inserted item or item just above the ones deleted

	def checkedItemsLeft (self):		# Order n**2, usually replaced by external function
		theCheckedItemsLeft = []
		for checkedItem in self.checkedListNode.old:
			for item in self.listNode.new:
				if checkedItem == item:
					theCheckedItemsLeft.append (item)
					break
		return theCheckedItemsLeft			

	def itemFromListViewItem (self, listViewItem):
		if not listViewItem:
			item = None
		elif self.transformer:
			item = listViewItem.Tag
		elif len (listViewItem.SubItems) == 1:
			item = self.listNode.new [0] .__class__ (listViewItem.Text)
		else:
			item = []				
			for subItemIndex, listViewSubItem in enumerate (listViewItem.SubItems):
				item.append (self.listNode.new [0][subItemIndex] .__class__ (listViewSubItem.Text))
					
		return item

# <tree> = [<branch>, ...]
# <branch> = <item> | (<item>, <tree>)

class TreeView (EnabledViewMix, FocusViewMix):	# Views a <tree>

	# --- Constructor and widget creation method, like supported by all views
	
	def __init__ (
		self,
		treeNode,
		selectedPathNode = None,
		enabled = None,
		contextMenuView = None,
		transformer = None,
		expansionLevel = None,
		dragObjectGetter = None,
		dragResultGetter = None,
		dropResultGetter = None,
		dropActionGetter = None,
		hoverPathNode = None,
		hintGetter = None,
		tweaker = None
	):
		EnabledViewMix.__init__ (self, enabled)
		FocusViewMix.__init__ (self)	
	
		self.treeNode = treeNode
		self.selectedPathNode = selectedPathNode
		self.contextMenuView = contextMenuView
		self.transformer = transformer
		self.expansionLevelNode = getNode (expansionLevel)
		self.dragObjectGetter = dragObjectGetter
		self.dragResultGetter = dragResultGetter
		self.dropResultGetter = dropResultGetter
		self.dropActionGetter = dropActionGetter
		self.hoverPathNode = hoverPathNode
		self.hintGetter = hintGetter
		self.tweaker = tweaker
		self.stretchHeight = True
				
	def createWidget (self):
		self.widget = Forms.TreeView ()
		self.attachEnabledToWidget ()
		self.attachFocusToWidget ()	
		self.widget.Dock = Forms.DockStyle.Fill
		self.widget.HideSelection = False
		self.widget.AllowDrop = True

		self.visibleTreeNode = Node ([])
		
		if self.expansionLevelNode:
			self.visibleTreeNode.dependsOn ([self.treeNode, self.expansionLevelNode], lambda: None)
		else:
			self.visibleTreeNode.dependsOn ([self.treeNode], lambda: None)
	
		self.visibleTreeLink = Link (self.visibleTreeNode, None, lambda: self.bareWrite ()) 
		self.visibleTreeLink.write ()			

		self.interestingPathsNode = Node ([])
		self.interestingPathsNode.dependsOn ([self.treeNode], lambda: self.interestingPaths ())

		if self.selectedPathNode:
			if not hasattr (self.selectedPathNode, 'getter'):
				self.selectedPathNode.dependsOn ([self.interestingPathsNode], lambda: self.interestingPathsNode.new [0])
				
			self.selectedPathLink = Link (self.selectedPathNode, lambda params: self.visibleTreeLink.writing or self.selectedPathNode.change (self.pathFromTreeViewNode (self.widget.GetNodeAt (params [1] .Location))), self.bareWriteSelectedPath)
			# Leave self.selectedPathLink.writeBack == True to properly deal with rightclicks. Probably bug in WinForms, because not needed with ListView.
			self.widget.MouseDown += self.selectedPathLink.read		# This is the only event already occurring at mouse down, so before a drag
		
		self.visiblePathNode = Node ([])			
		self.visiblePathNode.dependsOn ([self.interestingPathsNode], lambda: self.interestingPathsNode.new [1])
		self.visiblePathLink = Link (self.visiblePathNode, None, lambda: self.treeViewNodeFromPath (self.visiblePathNode.new) .EnsureVisible ())				
		
		if self.contextMenuView:
			self.widget.ContextMenuStrip = self.contextMenuView.createWidget ()
			self.widget.MouseUp += lambda sender, event: event.Button != Forms.MouseButtons.Right or sender.ContextMenuStrip.Show (sender, event.Location)
					
		if self.dropActionGetter:
			self.dragLink = Link (self.treeNode, lambda params: self.treeNode.change (self.dragResultGetter ()), None)
			self.dropLink = Link (self.treeNode, lambda params: self.treeNode.change (self.dropResultGetter (params [0], params [1])), None)
			
			self.widget.ItemDrag += self.itemDrag
			self.widget.DragEnter += self.dragEnter
			self.widget.DragOver += self.dragOver
			self.widget.DragLeave += self.dragLeave
			self.widget.DragDrop += self.dragDrop
			
		self.toolTip = Forms.ToolTip ()
		self.toolTip.ShowAlways = True
		self.hoverTreeViewNode = None
		self.widget.MouseMove += self.track

		tweak (self)
		return self.widget

	# --- Low level read methods to be passed to Links
	
	# None here, all coded as lambdas
	
	# --- Low level write methods to be passed to Links
	
	def bareWriteSelectedPath (self):	# Assignment can't be directly replaced by a lambda
		self.widget.SelectedNode = self.treeViewNodeFromPath (self.selectedPathNode.new)
				
	def bareWrite (self):
		expansionDictionary = {}
		self.fillExpansionDictionary (self.widget.Nodes, (), expansionDictionary)
		self.widget.Nodes.Clear ()
		self.writeTree (self.treeNode.new, self.widget.Nodes, (), expansionDictionary)
		
	def writeTree (self, tree, widgetNodes, hashPath, expansionDictionary):
		for branch in tree:
			widgetNode = Forms.TreeNode ()
			
			if branch.__class__ == tuple:
				item = branch [0]
				itemText = str (item)
				
				if self.transformer:
					newHashPath = hashPath + (item, )
				else:
					newHashPath = hashPath + (itemText, )
									
				self.writeTree (branch [1], widgetNode.Nodes, newHashPath, expansionDictionary)
			else:
				item = branch
				itemText = str (item)
				
				if self.transformer:
					newHashPath = hashPath + (item, )
				else:
					newHashPath = hashPath + (itemText, )
			
			if self.transformer:
				widgetNode.Tag = item
				
				bugFix = self.transformer (item)
				widgetNode.Text = bugFix
			else:
				widgetNode.Text = itemText
					
			try:
				if self.expansionLevelNode:
					if self.expansionLevelNode.new > len (hashPath) + 1:
						widgetNode.Expand ()
				elif expansionDictionary [newHashPath]:
					widgetNode.Expand ()
			except KeyError:						# ... Modified y06m05d08
				pass
			
			widgetNodes.Add (widgetNode)		

	# --- Drag and drop support methods
	
	def setTargetTreeViewNode (self, event):
		# From the combination (self.targetTreeViewNode, self.targetValid, self.onTarget) the insertion location can be deduced:
		# - (<anItem>, True, False) means: insert below underlined node
		# - (<anItem>, True, True) means: insert into highLighted node
		# - (None, True, False) means: insert above top node
		# - (None, False, False) means: invalid insertion location
		
		try:
			topTreeViewNode = self.widget.TopNode
			
			mousePoint = self.widget.PointToClient (Drawing.Point (event.X, event.Y))						# Normalized mouse cursor
			targetPoint = Drawing.Point (mousePoint.X, mousePoint.Y + topTreeViewNode.Bounds.Height / 4)	# Node above rather than under mouse cursor
			
			self.targetTreeViewNode = self.widget.GetNodeAt (targetPoint.X, targetPoint.Y)
			self.targetValid = True																			# Even when targetTreeViewNode is None
			
			# Selection area is is symetric around targetPoint
			# On target area should cover exactly half the selection area
			# First assume targetPoint == mousePoint, derive selection area and from that the on target area
			# Then translate both area's the over targetPoint.y - mousePoint.y
			self.onTarget = self.targetValid and self.targetTreeViewNode.Bounds.Top + topTreeViewNode.Bounds.Height / 4 < mousePoint.Y < self.targetTreeViewNode.Bounds.Bottom - topTreeViewNode.Bounds.Height / 4
		except AttributeError:	# topTreeViewNode is None or self.targetTreeViewNode is None, None doesn't have Bounds attribute
			self.targetTreeViewNode = None
			self.onTarget = False

			if self.treeNode.new == []:
				self.targetValid = True
			else:
				self.fillLastExpandedTreeViewNode ()
				self.targetValid = self.lastExpandedTreeViewNode.Bounds.Bottom < self.widget.ClientSize.Height - 1
				
	def drawTargetLine (self, appear):
		try:
			if self.onTarget:
				if appear:
					self.oldForeColor = self.targetTreeViewNode.ForeColor
					self.oldBackColor = self.targetTreeViewNode.BackColor

					self.targetTreeViewNode.ForeColor = Drawing.SystemColors.HighlightText
					self.targetTreeViewNode.BackColor = Drawing.SystemColors.Highlight
				else:
					self.targetTreeViewNode.ForeColor = self.oldForeColor
					self.targetTreeViewNode.BackColor = self.oldBackColor	
			elif self.targetValid:
				color = ifExpr (appear, Drawing.Color.Blue, Drawing.Color.White)
				
				if self.targetTreeViewNode:
					self.widget.CreateGraphics () .DrawLine (Drawing.Pen (color, 1), self.targetTreeViewNode.Bounds.Left, self.targetTreeViewNode.Bounds.Top, self.targetTreeViewNode.Bounds.Right, self.targetTreeViewNode.Bounds.Top)
				elif self.treeNode.new != []:
					self.widget.CreateGraphics () .DrawLine (Drawing.Pen (color, 1), 0, self.lastExpandedTreeViewNode.Bounds.Bottom, self.widget.ClientSize.Width, self.lastExpandedTreeViewNode.Bounds.Bottom)
		except:
			pass
				
	def itemDrag (self, sender, event):
		self.widget.Focus ()
	
		dragObject.sourceView = self
		dragObject.value = self.dragObjectGetter ()
	
		if self.widget.DoDragDrop (str (dragObject.value), Forms.DragDropEffects.Move | Forms.DragDropEffects.Copy) != Forms.DragDropEffects.None:
			self.dragLink.read ()
		
		dragObject.clear ()
				
	def dragDrop (self, sender, event):
		self.widget.HideSelection = False
		self.widget.Focus ()
		
		self.drawTargetLine (False)

		dragObject.keyState = event.KeyState	# Don't use directly, use dragObject.modifiers property instead		
		dragObject.dropAction = self.dropActionGetter ()
		
		if dragObject.dropAction and self.targetValid:
			try:		
				if self.targetTreeViewNode:
					self.dropLink.read (self.pathFromTreeViewNode (self.targetTreeViewNode), not self.onTarget)
				else:
					self.dropLink.read ([], False)
			except Refusal, refusal:
				handleNotification (refusal) 
				event.Effect = Forms.DragDropEffects.None
		
		if dragObject.imported:
			dragObject.clear ()
				
	def dragEnter (self, sender, event):
		self.widget.HideSelection = True
		
		event.Effect = event.AllowedEffect
		
		self.targetTreeViewNode = None	
		self.targetValid = False
			
		if dragObject.imported:
			dragObject.value = eval (event.Data.GetData (Forms.DataFormats.Text))
			
		dragObject.targetView = self
		
	def dragOver (self, sender, event):
		self.drawTargetLine (False)
		
		dragObject.keyState = event.KeyState	# Don't use directly, use dragObject.modifiers property instead		
		dropAction = self.dropActionGetter ()
	
		if dropAction:						
			self.setTargetTreeViewNode (event)

			event.Effect = ifExpr (self.targetValid,
				ifExpr (dropAction == DropActions.Move,
					Forms.DragDropEffects.Move,
					Forms.DragDropEffects.Copy),
				Forms.DragDropEffects.None)
			
			self.drawTargetLine (True)
							
		else:
			event.Effect = Forms.DragDropEffects.None
										
	def dragLeave (self, sender, event):
		self.widget.HideSelection = False
		
		self.drawTargetLine (False)
		
		if dragObject.imported:
			dragObject.clear ()
			
		dragObject.targetView = None

	# --- Miscellaneous methods
	
	def track (self, sender, event):
		hoverTreeViewNode = self.widget.GetNodeAt (event.Location)
		if not hoverTreeViewNode is self.hoverTreeViewNode:
			self.hoverTreeViewNode = hoverTreeViewNode
			
			if self.hoverPathNode:
				self.hoverPathNode.change (self.pathFromTreeViewNode (self.hoverTreeViewNode))
				
			self.toolTip.Active = False
			
			if self.hintGetter and self.hoverTreeViewNode:
				self.toolTip.SetToolTip (self.widget, getHint (self.hintGetter))
				self.toolTip.Active = True
	
	def assignSelectedTreeViewNode (self, treeViewNode):
		self.widget.SelectedNode = treeViewNode		
				
	def itemFromTreeViewNode (self, treeViewNode):
		if not treeViewNode:
			return None
		
		rootBranch  = self.treeNode.new [0]
		
		if self.transformer:
			return treeViewNode.Tag
		elif rootBranch.__class__ == tuple:
			return rootBranch [0] .__class__ (treeViewNode.Text)
		else:
			return rootBranch.__class__ (treeViewNode.Text)
			
	def pathFromTreeViewNode (self, treeViewNode):
		path = []
		while not treeViewNode is None:
			path.insert (0, self.itemFromTreeViewNode (treeViewNode))
			treeViewNode = treeViewNode.Parent
			
		return path
	
	def treeViewNodeFromPath (self, path):
		treeViewNodes = self.widget.Nodes
		treeViewNode = None						# ... Added y06m05d08
		
		for item in path:
			for treeViewNode in treeViewNodes:
				candidateItem = self.itemFromTreeViewNode (treeViewNode)
				
				if candidateItem == item:
					treeViewNodes = treeViewNode.Nodes
					break
					
		return treeViewNode		
		
	def interestingPaths (self):
		selectedPath = []
		visiblePath = []
		self.fillInterestingPaths (self.treeNode.new, self.treeNode.old, selectedPath, visiblePath, [True])
		return (selectedPath, visiblePath)

	def fillInterestingPaths (self, newTree, oldTree, selectedPath, visiblePath, select):
		newIndex = len (newTree) - 1
		oldIndex = len (oldTree) - 1
		
		growth = newIndex - oldIndex
		
		while newIndex >= 0 and oldIndex >= 0:
			newBranch = tupleFromBranch (newTree [newIndex])
			oldBranch = tupleFromBranch (oldTree [oldIndex])
			
			if newBranch [0] == oldBranch [0]:
				if self.fillInterestingPaths (newBranch [1], oldBranch [1], selectedPath, visiblePath, select):
					if select [0]:
						selectedPath.insert (0, newBranch [0])
					visiblePath.insert (0, newBranch [0])
					return True
			else:
				if growth <= 0:
					selectedPath.insert (0, newBranch [0])
				visiblePath.insert (0, newBranch [0])
				return True
			
			newIndex -= 1
			oldIndex -= 1
			
		if newIndex >= 0:
			visiblePath.insert (0, tupleFromBranch (newTree [newIndex]) [0])
			return True
		
		if oldIndex >= 0:
			select [0] = False
			return True
			
		return False		
	
	def fillExpansionDictionary (self, treeViewNodes, hashPath, expansionDictionary):
		for treeViewNode in treeViewNodes:
			if self.transformer:
				newHashPath = hashPath + (treeViewNode.Tag, )
			else:
				newHashPath = hashPath + (treeViewNode.Text, )	# Store as string since its used in View rather than Node
				
			expansionDictionary [newHashPath] = treeViewNode.IsExpanded
			self.fillExpansionDictionary (treeViewNode.Nodes, newHashPath, expansionDictionary)
			
	def fillLastExpandedTreeViewNode (self):
		currentTreeViewNode = None	# Virtual parent of root(s)
		expanded = True				# Always expanded	
		treeViewNodes = self.widget.Nodes
		
		while expanded and len (treeViewNodes) > 0:
			currentTreeViewNode = treeViewNodes [len (treeViewNodes) - 1]
			expanded = currentTreeViewNode.IsExpanded
			treeViewNodes = currentTreeViewNode.Nodes
			
		self.lastExpandedTreeViewNode = currentTreeViewNode
			
class GroupView:
	def __init__ (self, clientView, caption, tweaker = None):
		self.clientView = clientView
		self.captionNode = getNode (caption)
		self.stretchHeight = False
		self.tweaker = tweaker
		
	def createWidget (self):
		self.widget = Forms.GroupBox ()
		self.widget.Dock = Forms.DockStyle.Fill
		
		self.widget.Controls.Add (self.clientView.createWidget ())
		
		if self.clientView.stretchHeight:
			self.stretchHeight = True
		else:
			self.widget.MinimumSize = Drawing.Size (0, self.clientView.widget.PreferredSize.Height + 20)
		
		self.captionLink = Link (self.captionNode, None, lambda: assignText (self.widget, str (self.captionNode.new)))			
		self.captionLink.write ()
		
		tweak (self)
		return self.widget
			
class PageView (FocusViewMix):
	def __init__ (self, clientView, caption, enabled = None, tweaker = None):
		FocusViewMix.__init__ (self)
		self.clientView = clientView
		self.captionNode = getNode (caption)
		self.enabledNode = getNode (enabled)
		self.tweaker = tweaker
		
		self.tabbedView = None

	def getSelected (self):
		try:
			return self.pageIndex == self.tabbedView.widget.SelectedIndex
		except AttributeError:	# self.tabbedView is None or tabbedView does not yet have a widget
			return False

	selected = property (getSelected)

	def createWidget (self):
		self.widget = Forms.TabPage ()
		self.attachFocusToWidget ()
		self.widget.Controls.Add (self.clientView.createWidget ())
				
		if not hasattr (self, 'captionLink'):	
			self.captionLink = Link (self.captionNode, None, lambda: assignText (self.widget, str (self.captionNode.new)))
		self.captionLink.write ()
		
		if self.enabledNode:
			if not hasattr (self, 'enabledLink'):
				self.enabledLink = Link (self.enabledNode, None, self.occur)
			self.enabledLink.write ()
		else:
			self.tabbedView.widget.Controls.Add (self.widget)
		
		tweak (self)
		return self.widget
		
	def occur (self):
		try:
			if self.enabledNode.new:
				self.tabbedView.widget.Controls.Add (self.widget)
			else:
				self.tabbedView.widget.Controls.Remove (self.widget)
		except:
			pass

class TabbedView:
	def __init__ (self, pageViews, selectedIndex = None, tweaker = None):
		for pageIndex, pageView in enumerate (pageViews):
			pageView.tabbedView = self
			pageView.pageIndex = pageIndex
			
		self.pageViews = pageViews
		self.selectedIndexNode = getNode (selectedIndex)
		self.tweaker = tweaker
		self.stretchHeight = True
		
	def createWidget (self):
		self.widget = Forms.TabControl ()
		self.widget.Dock = Forms.DockStyle.Fill
		
		if self.selectedIndexNode:
			self.selectedIndexLink = Link (self.selectedIndexNode, lambda params: self.selectedIndexNode.change (self.widget.SelectedIndex), self.bareWriteSelectedIndex)
			self.selectedIndexLink.writeBack = False
			self.widget.SelectedIndexChanged += self.selectedIndexLink.read
			self.selectedIndexLink.write ()
			
		for pageView in self.pageViews:
			pageView.createWidget ()
			
		tweak (self)
		return self.widget 
	
	def bareWriteSelectedIndex (self):
		self.widget.SelectedIndex = self.selectedIndexNode.new
	
class GridView:
	def __init__ (self, childViews, tweaker = None):
		self.childViews = childViews
		self.tweaker = tweaker
		self.stretchHeight = False
		
	def createWidget (self):
		self.widget = Forms.TableLayoutPanel ()
		self.widget.Dock = Forms.DockStyle.Fill
		
		for rowIndex, childViewRow in enumerate (self.childViews):
			stretchRowHeight = False
			preferredRowHeight = 0
			for columnIndex, childView in enumerate (childViewRow):
				if not childView.__class__ in [HExtensionView, VExtensionView, EmptyView]:
				
					sentryColumnIndex = columnIndex + 1		
					try:
						while childViewRow [sentryColumnIndex] .__class__ is HExtensionView:
							sentryColumnIndex += 1
					except:
						pass
					nrOfColumns = sentryColumnIndex - columnIndex
					
					sentryRowIndex = rowIndex + 1
					try:
						while self.childViews [sentryRowIndex] [columnIndex] .__class__ is VExtensionView:
							sentryRowIndex += 1
					except:
						pass
					nrOfRows = sentryRowIndex - rowIndex					
					
					self.widget.Controls.Add (childView.createWidget (), columnIndex, rowIndex)
					
					self.widget.SetColumnSpan (childView.widget, nrOfColumns)
					self.widget.SetRowSpan (childView.widget, nrOfRows)
					
					if childView.stretchHeight:
						stretchRowHeight = True
					elif childView.widget.PreferredSize.Height > preferredRowHeight:
						preferredRowHeight = childView.widget.PreferredSize.Height
					
			rowStyle = Forms.RowStyle ()
			
			if stretchRowHeight:
				self.stretchHeight = True
				
				rowStyle.SizeType = Forms.SizeType.Percent
				rowStyle.Height = 100 
			else:
				rowStyle.SizeType = Forms.SizeType.Absolute
				rowStyle.Height = preferredRowHeight + 7
				
			self.widget.RowStyles.Add (rowStyle)
					
		gridWidth = 0
		for childViewRow in self.childViews:
			gridWidth = max (gridWidth, len (childViewRow))
	
		for columnIndex in range (gridWidth):
			columnStyle = Forms.ColumnStyle ()
			columnStyle.SizeType = Forms.SizeType.Percent
			columnStyle.Width = 100 / gridWidth
			self.widget.ColumnStyles.Add (columnStyle)
							
		tweak (self)						
		return self.widget

class HGridView (GridView):
	def __init__ (self, childViews, tweaker = None):
		GridView.__init__ (self, [childViews], tweaker)
		
class VGridView (GridView):
	def __init__ (self, childViews, tweaker = None):
		childRows = []
		for childView in childViews:
			childRows.append ([childView])
			
		GridView.__init__ (self, childRows, tweaker)
	
class SplitViewBase:
	def __init__ (self, childView1, childView2, key, tweaker):
		self.childView1 = childView1
		self.childView2 = childView2
		self.tweaker = tweaker
		
		self.stretchHeight = True
		
		currentViewStore () .add (self, key)

	def createWidget (self):
		self.widget = Forms.SplitContainer ()
		self.widget.Dock = Forms.DockStyle.Fill
		
		def setState (sender, event):
			self.state = (1.0 * self.widget.SplitterDistance) / self.getMaxSplitterDistance ()

		def getStateAndAllowSetState (sender, event):
			if self.widget.Visible:
				if hasattr (self, 'state'):	# Either from viewStore or from previously closed modal dialog widget
					try:
						self.widget.SplitterDistance = int (self.state * self.getMaxSplitterDistance ())
					except:	# If impossible to obey, due to e.g. minimum size
						pass
					
				self.widget.SplitterMoved += setState
		
		self.widget.VisibleChanged += getStateAndAllowSetState
		
		self.widget.Panel1.Controls.Add (self.childView1.createWidget ())		
		self.widget.Panel2.Controls.Add (self.childView2.createWidget ())
		
		return self.widget
	
class HSplitView (SplitViewBase):
	def __init__ (self, leftChildView, rightChildView, key = None, tweaker = None):
		SplitViewBase.__init__ (self, leftChildView, rightChildView, key, tweaker)
		
	def createWidget (self):
		SplitViewBase.createWidget (self)
		return self.widget
		
	def getMaxSplitterDistance (self):
		return self.widget.Width
		
class VSplitView (SplitViewBase):
	def __init__ (self, topChildView, bottomChildView, key = None, tweaker = None):
		SplitViewBase.__init__ (self, topChildView, bottomChildView, key, tweaker)
		
	def createWidget (self):
		SplitViewBase.createWidget (self)
		self.widget.Orientation = Forms.Orientation.Horizontal
		tweak (self)
		return self.widget
		
	def getMaxSplitterDistance (self):
		return self.widget.Height
	
class HExtensionView:
	pass
	
class VExtensionView:
	pass
	
class EmptyView:
	pass

class MenuBarView:
	def __init__ (self, menuItemViews, tweaker = None):
		self.menuItemViews = menuItemViews
		self.tweaker = tweaker
		
	def createWidget (self):
		self.widget = Forms.MenuStrip ()

		for menuItemView in self.menuItemViews:
			self.widget.Items.Add (menuItemView.createWidget ())
			
		tweak (self)
		return self.widget
		
class ContextMenuView:
	def __init__ (self, menuItemViews, tweaker = None):
		self.menuItemViews = menuItemViews
		self.tweaker = tweaker
		
	def closeFix (self, sender, event):
		# Don't block closing, this will cause a deadlock if the app's close button is clicked.
		# Just prepend a better way of closing
		if event.CloseReason == Forms.ToolStripDropDownCloseReason.AppClicked:
			Forms.SendKeys.SendWait ('{ESC}')
				
	def createWidget (self):
		self.widget = Forms.ContextMenuStrip ()
		self.widget.Closing += self.closeFix

		for menuItemView in self.menuItemViews:
			self.widget.Items.Add (menuItemView.createWidget ())
			
		tweak (self)
		return self.widget		

class MenuListView:
	def __init__ (self, menuItemViews, caption, tweaker = None):
		self.menuItemViews = menuItemViews
		self.captionNode = getNode (caption)
		self.tweaker = tweaker
		
	def createWidget (self):
		self.widget = Forms.ToolStripMenuItem ()
				
		for menuItemView in self.menuItemViews:
			self.widget.DropDownItems.Add (menuItemView.createWidget ())
		
		self.captionLink = Link (self.captionNode, None, lambda: assignText (self.widget, str (self.captionNode.new)))		
		self.captionLink.write ()
		
		tweak (self)
		return self.widget

class MenuSeparatorView:
	def __init__ (self, tweaker = None):
		self.tweaker = tweaker
		
	def createWidget (self):
		self.widget = Forms.ToolStripSeparator ()
		tweak (self)
		return self.widget

class WindowViewBase (object, KeysViewMix):
	def __init__ (self, clientView, caption, menuBarView, key, fixedSize, tweaker, keysDownNode, keysUpNode, keyCharNode, keysHandled):
		KeysViewMix.__init__ (self, keysDownNode, keysUpNode, keyCharNode, keysHandled)
		self.clientView = clientView
		self.captionNode = getNode (caption)
		self.menuBarView = menuBarView
		self.fixedSize = fixedSize
		self.tweaker = tweaker

		currentViewStore () .add (self, key)
		
	def createWidget (self):	# ??? bareCreateWidget, just as with buttons?
		self.widget = Forms.Form ()		
		self.attachKeysToWidget ()

		if self.keysDownNode or self.keysUpNode or self.keyCharNode or self.keysHandled:
			self.widget.KeyPreview = True
		
		if hasattr (self, 'state'):	# Either from viewStore or from previously closed modal dialog widget
			if (currentViewStore () is mainViewStore):
				self.widget.StartPosition = Forms.FormStartPosition.Manual
				self.widget.Left, self.widget.Top, self.widget.Width, self.widget.Height = self.state
			else:
				self.widget.StartPosition = Forms.FormStartPosition.WindowsDefaultLocation
				self.widget.Width, self.widget.Height = self.state [2:]
		else:
			self.widget.StartPosition = Forms.FormStartPosition.WindowsDefaultBounds
		
		def setState (sender, event):
			self.widget.StartPosition = Forms.FormStartPosition.Manual	# Modal dialog widget may be reshown using StartPosition, without being recreated
			self.state = self.widget.Left, self.widget.Top, self.widget.Width, self.widget.Height

		self.widget.Move += setState
		self.widget.Resize += setState
		
		childViews = [self.clientView]
		if self.menuBarView:
			childViews.append (self.menuBarView)
			
		for childView in childViews:
			self.widget.Controls.Add (childView.createWidget ())
			
		self.captionLink = Link (
			self.captionNode,
			None,
			lambda: assignText (self.widget, ifExpr (application.designMode, '[DESIGN MODE] ', '') + str (self.captionNode.new))
		)
		
		self.captionLink.write ()

		return self.widget
		
	def execute (self):
		try:
			self.bareExecute ()
		except Refusal, refusal:
			handleNotification (refusal)
		except Exception, exception:
			problem = 'Cannot execute widget, '
			handleNotification (Error (problem + exMessage (exception), report = problem + exReport (exception)))

	def exit (self):
		self.widget.Hide ()
		
class MainView (WindowViewBase):
	def __init__ (
		self,
		clientView,
		caption,
		menuBarView = None,
		viewStoreFileName = 'views.store',
		key = None,
		fixedSize = False,
		tweaker = None,
		keysDownNode = None,
		keysUpNode = None,
		keyCharNode = None,
		keysHandled = None
	):
		application.mainView = self
		WindowViewBase.__init__ (self, clientView, caption, menuBarView, key, fixedSize, tweaker, keysDownNode, keysUpNode, keyCharNode, keysHandled)
		Forms.Application.EnableVisualStyles ()
		self.viewStoreFileName = viewStoreFileName
	
	def createWidget (self):
		WindowViewBase.createWidget (self)			

		if self.fixedSize and not application.designMode:		
			self.widget.FormBorderStyle = Forms.FormBorderStyle.FixedDialog
		else:
			self.widget.FormBorderStyle = Forms.FormBorderStyle.Sizable
	
		tweak (self)		
		return self.widget
		
	def bareExecute (self):
		mainViewStore.load (self.viewStoreFileName)
		self.createWidget ()	
		self.widget.ShowDialog ()
		mainViewStore.save ()

	def exit (self):
		self.widget.Close ()
					
class ModalView (WindowViewBase):
	def __init__ (
		self,
		clientView,
		caption,
		menuBarView = None,
		key = None,
		fixedSize = False,
		tweaker = None,
		keysDownNode = None,
		keysUpNode = None,
		keyCharNode = None,
		keysHandled = None
	):
		WindowViewBase.__init__ (self, clientView, caption, menuBarView, key, fixedSize, tweaker, keysDownNode, keysUpNode, keyCharNode, keysHandled)
		
	def createWidget (self):
		WindowViewBase.createWidget (self)
		
		if self.fixedSize and not application.designMode:		
			self.widget.FormBorderStyle = Forms.FormBorderStyle.FixedDialog
		else:
			self.widget.FormBorderStyle = Forms.FormBorderStyle.Sizable

		self.widget.MinimizeBox = False
		self.widget.MaximizeBox = False
		self.widget.ShowInTaskbar = False
				
		tweak (self)
		return self.widget

	def bareExecute (self):
		if not hasattr (self, 'widget'):
			self.createWidget ()
			
		self.widget.ShowDialog ()
			
class ModelessView (WindowViewBase):
	def __init__ (
		self,
		clientView,
		caption,
		menuBarView = None,
		key = None,
		fixedSize = False,
		exitActionNode = None,
		tweaker = None,
		keysDownNode = None,
		keysUpNode = None,
		keyCharNode = None,
		keysHandled = None
	):
		WindowViewBase.__init__ (self, clientView, caption, menuBarView, key, fixedSize, tweaker, keysDownNode, keysUpNode, keyCharNode, keysHandled)
		self.exitActionNode = exitActionNode
		
	def createWidget (self):
		WindowViewBase.createWidget (self)
		
		def onFormClosing (sender, event):
			event.Cancel = True
			self.widget.Hide ()
		
		self.widget.FormClosing += onFormClosing
		
		if self.exitActionNode:
			self.exitActionLink = Link (self.exitActionNode, lambda params: self.exitActionNode.change (None, True), None)			
			self.widget.Closed += self.exitActionLink.read
					
		if self.fixedSize and not application.designMode:		
			self.widget.FormBorderStyle = Forms.FormBorderStyle.FixedToolWindow
		else:
			self.widget.FormBorderStyle = Forms.FormBorderStyle.SizableToolWindow
				
		self.widget.ShowInTaskbar = False
		
		tweak (self)
		return self.widget

	def bareExecute (self):
		if not hasattr (self, 'widget'):
			self.createWidget ()
			self.widget.Owner = application.mainView.widget
			
		self.widget.Show ()
