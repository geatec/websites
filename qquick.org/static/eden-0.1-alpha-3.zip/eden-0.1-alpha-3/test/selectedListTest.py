from eden import *

startNode = Node (0)
itemsNode = Node (3)

refreshNode = Node (None)
refreshNode

listNode = Node ()
listNode.dependsOn ([startNode, itemsNode, refreshNode], lambda: [startNode.new + i for i in range (itemsNode.new)])

selectedListNode = Node ([])
selectedListNode.trace ('selectedListNode')

def transform (number):
	return [10 * number]

MainView (
	HGridView ([
		TextView (startNode),
		TextView (itemsNode),
		ButtonView (refreshNode, 'Refresh'),
		ListView (listNode = listNode, columnLabels = ['all'], selectedListNode = selectedListNode, transformer = transform),
		ListView (listNode = selectedListNode, columnLabels = ['selection'])
	]),
	'Test'
) .execute ()
