# Copyright (C) 2005, 2006 Jacques de Hooge, Geatec Engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.

import clr

clr.AddReference ('System.Drawing')
clr.AddReference ('System.Windows.Forms')

from System import Drawing
from System.Windows import Forms

from edenLib.base import *
from edenLib.view import *

class Font:
	Families = [Drawing.FontFamily.GenericMonospace, Drawing.FontFamily.GenericSansSerif, Drawing.FontFamily.GenericSerif]
	Fixed, PropSansSerif, PropSerif  = range (len (Families))
	
	Styles = [Drawing.FontStyle.Bold, Drawing.FontStyle.Italic, Drawing.FontStyle.Regular, Drawing.FontStyle.Strikeout, Drawing.FontStyle.Underline]
	Bold, Italic, Regular, StrikeOut, Underlined = range (len (Styles))
	
	@classmethod
	def tweak (cls, view, family = Fixed, size = 10, styles = [Regular]):
		styleCombi = cls.Styles [styles [0]]
		
		for style in styles [1:]:
			styleCombi |= cls.Styles [style]
			
		view.widget.Font = Drawing.Font (cls.Families [family], size, styleCombi)


