print '\nSets are unordered, so are no sequences'
print '\nSome specific things you can do with sets:'

s1 = set ('abcd')
s2 = set ('cdef')
s3 = set ('bc')

print 's1', s1, s1.__class__, 'Length =', len (s1)
print 's2', s2
print 's3', s3
print 
print 's1 & s2', s1 & s2
print 's1 | s2', s1 | s2
print 's1 ^ s2', s1 ^ s2
print 's2 - s3', s2 - s3
print 
print 's1 <= s2', s1 <= s2
print 's1 >= s2', s1 >= s2
print 's3 <= s1', s3 <= s1
print 's1 >= s3', s1 >= s3
print
s1.remove ('a')
s1.add ('z')
print s1
