from group1.moduleA import *
from group2.moduleB import *
import group1.moduleX as moduleX1
import group2.moduleX as moduleX2

a ()
b ()
moduleX1.x ()
moduleX2.x ()
