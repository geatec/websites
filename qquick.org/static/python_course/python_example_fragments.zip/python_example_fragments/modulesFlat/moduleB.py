def b ():
	print 'b'
