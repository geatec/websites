def x ():
	print 'x'
