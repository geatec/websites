def a ():
	print 'a'
