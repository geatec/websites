def x ():
	print 'X'
