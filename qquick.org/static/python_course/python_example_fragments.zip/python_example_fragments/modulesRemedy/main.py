from module import *

print application.a
f ()

application.a = 5
print

print application.a
f ()
