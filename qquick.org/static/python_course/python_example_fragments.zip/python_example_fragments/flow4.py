# raise

for i in range (10, -11, -1):
	try:
		print '100 /', i, '=',  100 / i
	except:
		print 'Caught!!!'
	
		