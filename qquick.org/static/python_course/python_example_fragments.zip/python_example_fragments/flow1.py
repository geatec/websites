# if

def f (a):
	if a == 1:
		print 'One'
	elif a == 2:
		print 'Two'
	elif a == 3:
		print 'Three'
	else:
		print 'Not one, two or three'

f (1)
f (2)
f (3)
f (4)
