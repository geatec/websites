a = 3

def f ():
	print a