Usage:

1. Download PythonForSimPyLC-0.1-alpha-1 into a directory by the same name and unpack it there
2. From the command prompt in that directory run setupPython32.bat or setupPython64.bat, depending on your processor
3. Copy QuartzMS.TTF into C:\Windows\Fonts

4. From the commandprompt in directoy SimPyLC run setupSymPyLC.bat
5. Go to directory oneArmedRobot and from the command prompt type python world.py
6. For an even simpler example go to directory blinkingLight and from the command prompt type python world.py

Operation:
	Left mousekey or enter gets you into edit mode.
	Left mousekey or enter again gets you out of edit mode and into forced mode, values coloured orange are frozen.
	Right mousekey or esc gets gets you into released mode, values are thawed again.
	PageUp and PageDown change the currently viewed control page.
	
