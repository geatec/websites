# ====== Legal notices
#
# Copyright (C) 2012, 2013 GEATEC engineering
#
# This program is free software.
# You can use, redistribute and/or modify it, but only under the terms stated in the QQuickLicence.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY, without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
# See the QQuickLicence for details.
#
# The QQuickLicense can be accessed at: http://www.geatec.com/qqLicence.html
#

# ====== Imports

from sys import *

# ====== Data classes occurring in an MSH file
	
class Vertex:
	def __init__ (self, coordinates):
		self.coordinates = coordinates

class Edge:
	pass
	
class Facet:
	def __init__ (self, vertexIndices, value):
		self.vertexIndices = vertexIndices
		self.value = value

class Cell:
	def __init__ (self, vertexIndices, value):
		self.vertexIndices = vertexIndices
		self.value = value	

# ====== MSH file reader	

class MshFileReader:
	def __init__ (self, fileName):
		self.fileName = fileName
		self.file = open (self.fileName, 'r')
		self.lines = self.file.readlines ()
		self.file.close ()
		self.lineIndex = 0 

		self.facetId = 2
		self.cellId = 4
		
		self.vertices = []
		self.facetsFromVertexIndex = []		
		self.facets = []
		self.cells = []
		
		self.parseMeshFormat ()
		self.parseNodes ()
		self.parseElements ()
			
	def exitWithError (self, description):
		print 'Error: {0} in file {1}, line {2} [{3}]'.format (description, self.fileName, self.lineIndex + 1, self.lines [self.lineIndex])
			
	def parseMeshFormat (self):
		if not self.lines [self.lineIndex] .startswith ('$MeshFormat'):
			self.exitWithError ('$MeshFormat expected')
		self.lineIndex += 1
		while True:
			line = self.lines [self.lineIndex]
			if line.startswith ('$EndMeshFormat'):
				break
			self.lineIndex += 1
		self.lineIndex += 1
	
	def parseNodes (self):
		if not self.lines [self.lineIndex].startswith ('$Nodes'):
			self.exitWithError ('$Nodes expected')
		self.lineIndex += 2	# Skip nr. of nodes
		while (True):
			line = self.lines [self.lineIndex]
			if line.startswith ('$EndNodes'):
				break
			numbers = [eval (word) for word in self.lines [self.lineIndex] .split ()]
			self.vertices.append (Vertex (numbers [1:4]))
			self.facetsFromVertexIndex.append (set ())
			self.lineIndex += 1
		self.lineIndex += 1
			
	def parseElements (self):
		if not self.lines [self.lineIndex] .startswith ('$Elements'):
			self.exitWithError ('$Elements expected')
		self.lineIndex += 2 # Skip nr. of elements
		while (True):
			line = self.lines [self.lineIndex]
			if line.startswith ('$EndElements'):
				break
			numbers = [eval (word) for word in self.lines [self.lineIndex] .split ()]
			if numbers [1] == self.facetId:
				vertexIndices = sorted ([number - 1 for number in numbers [5:8]])
				facet = Facet (vertexIndices, numbers [4])
				self.facets.append (facet)
				for vertexIndex in vertexIndices:
					self.facetsFromVertexIndex [vertexIndex] .add (facet)
			elif numbers [1] == self.cellId:
				vertexIndices = sorted ([number - 1 for number in numbers [5:9]])
				self.cells.append (Cell (vertexIndices, numbers [4]))
			self.lineIndex += 1
		self.lineIndex += 1

# ====== Tabbed writer

class TabbedWriter:
	def __init__ (self, fileName):
		self.level = 0;
		self.fileName = fileName
		self.file = open (self.fileName, 'w')
		
	def close (self):
		self.file.close ()
	
	def indent (self):
		self.level += 1
	
	def unindent (self):
		self.level -= 1
	
	def write (self, line):
		self.file.write ('\t' * self.level + line + '\n')

# ====== Dolfin mesh XML writer
			
class MeshXmlWriter (TabbedWriter):
	def __init__ (self, fileName, mshFileReader):
		TabbedWriter.__init__ (self, fileName)
		self.fileName = fileName
		self.file = open (self.fileName, 'w')
		self.mshFileReader = mshFileReader
		
		self.write ('<?xml version="1.0"?>')
		self.write ('<dolfin xmlns:geatec="http://geatec.com">')
		self.indent ()
		self.write ('<mesh celltype="tetrahedron" dim="3">')
		self.indent ()
		self.writeVertices ()
		self.writeCells ()
		self.unindent ()
		self.write ('</mesh>')
		self.unindent ()
		self.write ('</dolfin>')
		
	def writeVertices (self):
		self.write ('<vertices size="{0}">'.format (len (mshFileReader.vertices)))
		self.indent ()
		for vertexIndex, vertex in enumerate (mshFileReader.vertices):
			self.write ('<vertex index="{0}" x="{1}" y="{2}" z="{3}" />'.format (* ([vertexIndex] + vertex.coordinates)))
		self.unindent ()
		self.write ('</vertices>')
			
	def writeCells (self):
		self.write ('<cells size="{0}">'.format (len (mshFileReader.cells)))
		self.indent ()
		for cellIndex, cell in enumerate (mshFileReader.cells):
			self.write ('<tetrahedron index="{0}" v0="{1}" v1="{2}" v2="{3}" v3="{4}" />'.format (* ([cellIndex] + cell.vertexIndices)))
		self.unindent ()
		self.write ('</cells>')	

# ====== Dolfin mesh function XML file writers

class MeshFunctionXmlWriter (TabbedWriter):
	def __init__ (self, fileName, mshFileReader):
		TabbedWriter.__init__ (self, fileName)
		self.fileName = fileName
		self.file = open (self.fileName, 'w')
		self.mshFileReader = mshFileReader
		
		self.write ('<?xml version="1.0"?>')
		self.write ('<dolfin xmlns:geatec="http://www.geatec.com">')
		self.indent ()
		self.write ('<mesh_function>')
		self.indent ()
		self.writeValues ()
		self.unindent ()
		self.write ('</mesh_function>')
		self.unindent ()
		self.write ('</dolfin>')

class FacetMeshFunctionXmlWriter (MeshFunctionXmlWriter):
	def __init__ (self, fileName, mshFileReader):
		self.nrOfFacetsPerCell = 4
		MeshFunctionXmlWriter.__init__ (self, fileName, mshFileReader)
		
	def writeValues (self):
		valueLines = []
		for cellIndex, cell in enumerate (mshFileReader.cells):
			candidateFacets = set ()
			for vertexIndex in cell.vertexIndices:
				candidateFacets |= set (mshFileReader.facetsFromVertexIndex [vertexIndex])
			# candidateFacets now contains all facets that have at least 1 incident vertex to the cell
				
			facets = set ()
			for candidateFacet in candidateFacets:
				if len (set (candidateFacet.vertexIndices) & set (cell.vertexIndices)) == 3:
					facets.add (candidateFacet)
			# facets now contains all facets that have  3 indident vertices with the cell
					
			localValues = [100] * self.nrOfFacetsPerCell
			for facet in facets:
				globalFacetIndexSet = (set (cell.vertexIndices) - set (facet.vertexIndices))
				nrOfGlobalFacetIndices = len (globalFacetIndexSet)
				if len (globalFacetIndexSet) < 1:
					print 'Error: facet has no index'
				elif len (globalFacetIndexSet) > 1:
					print 'Error: ambiguous facet index'
				localFacetIndex = cell.vertexIndices.index (globalFacetIndexSet.pop ())
				localValues [localFacetIndex] = facet.value
			# localValues now contains function values at correct local index
				
			for localFacetIndex in range (self.nrOfFacetsPerCell):
				if localValues [localFacetIndex] != None:
					valueLines.append ('<value cell_index="{0}" local_entity="{1}" value="{2}" />'.format (cellIndex, localFacetIndex, localValues [localFacetIndex]))
				
		self.indent ()
		self.write ('<mesh_value_collection type="uint" dim="2" size="{0}">'.format (len (valueLines)))
		for valueLine in valueLines:
			self.write (valueLine)
		self.unindent ()
		self.write ('</mesh_value_collection>')
		
class CellMeshFunctionXmlWriter (MeshFunctionXmlWriter):
	def __init__ (self, fileName, mshFileReader):
		MeshFunctionXmlWriter.__init__ (self, fileName, mshFileReader)
		
	def writeValues (self):
		self.write ('<mesh_value_collection type="uint" dim="3" size="{0}">'.format (len (self.mshFileReader.cells)))
		self.indent ()
		for cellIndex, cell in enumerate (mshFileReader.cells):
			self.write ('<value cell_index="{0}" local_entity="0" value="{1}" />'.format (cellIndex, cell.value))
		self.unindent ()
		self.write ('</mesh_value_collection>')
		
# ====== Main
		
if len (argv) == 5: # Incl. name of program
	fileNames = argv [1:]
else:
	fileNames = ['defVolumes.msh', 'volumesMesh.xml', 'volumesFacetMeshFunction.xml', 'volumesCellMeshFunction.xml']
	
mshFileReader = MshFileReader (fileNames [0])
MeshXmlWriter (fileNames [1], mshFileReader)
FacetMeshFunctionXmlWriter (fileNames [2], mshFileReader)
CellMeshFunctionXmlWriter (fileNames [3], mshFileReader)
	