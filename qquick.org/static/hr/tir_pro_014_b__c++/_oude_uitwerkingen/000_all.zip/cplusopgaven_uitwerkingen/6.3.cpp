/*#include <iostream>
using namespace std; 

// opg 6.3

void wissel(string  &x , string &y)
  { string h ;
      h=x ; x=y ; y=h;
  }  

void sorteer3strings(string &s, string &t, string &u)
   { if ( s > t ) wissel(s,t);
     if ( t > u ) wissel(t,u);
     if ( s > t ) wissel(s,t);
    }   
int main(int argc , char *argv[])
 { string  s,t,u;
   int c ;
    s=argv[1];
    t=argv[2];
    u=argv[3];
    sorteer3strings(s,t,u);
    cout << s <<  t <<  u << endl;     
    cin >> c;
   return 0;
     
  }*/
