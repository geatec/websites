#include <iostream>
// opgave 1.8 
 
using namespace std;
int main()
{
 char ch;
 cout <<  "Apostrof: \'\nAanhalingsteken: \"\n"
                     "Backslash: \\\n\nEinde.\n";
 system("Pause");
}
