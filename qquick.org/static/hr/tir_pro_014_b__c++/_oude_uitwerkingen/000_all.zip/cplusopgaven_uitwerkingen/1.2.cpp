#include <iostream>
using namespace std;

// opgave 1.2

int main()
{ int a ;
    char ch;
    cin >> ch ;
    ch=ch +1;
    cout <<  ch  << endl ;
    cin >> a;
    return 0;
     
}
