#include <iostream>
using namespace std;

// opgave 2.9

int main()
{ int s=0,i,a ;   
     
      for ( i=1 ; i < 10  ;i++ )  //;  De ; verwijderen 
       s += i ;
      cout << s << endl;
      cin >> a;
    return 0;
     
}
