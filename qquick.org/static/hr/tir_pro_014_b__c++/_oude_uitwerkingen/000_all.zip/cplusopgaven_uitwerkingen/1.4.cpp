#include <iostream>

// opgave 1.4

using namespace std;
int main()
{
 char ch;
 cin >> ch;
 ch=ch+1;
 cout << ch<<endl;;
 return 0;
}
