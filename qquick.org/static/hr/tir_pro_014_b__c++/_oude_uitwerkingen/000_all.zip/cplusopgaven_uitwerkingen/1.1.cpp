#include <iostream>

// opgave 1.1

using namespace std;
int main()
{ int a, leeftijd;//, geboortejaar;
    cout << "Hallo, type je leeftijd\n";
    cin >> leeftijd ;
    //cin >> geboortejaar ;
      leeftijd <<=10;
     cout << leeftijd << endl; 
     cin >> a;
     return 0;
     
}
