A simple and straight C course, written for people who never programmed before.
Target audience are students Technical Computer Science.

No need to waste time installing a compiler, since all examples run unmodified on repl.it.
A course of 7 to 8 lessons of 2 hours each plus some homework should be enough to cover this material.

In the end C++ is the target to aim at.
It's just as fast as C but allows for much more structure and clarity.
However, C and procedural imperative programming are a good place to start.
